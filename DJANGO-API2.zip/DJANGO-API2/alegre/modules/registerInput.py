from modules.provisioningSigfoxFile import *
# Import pandas
import pandas as pd

# Load the xlsx file
excel_data = pd.read_excel('ejemplo_Registro_contenedores.xlsx')
# Read the values of the file in the dataframe, with format of a array
data1 = pd.DataFrame(excel_data, columns=['ID Dispositivo','ID Contendor','Ref Interno','Ref Pieza']).to_numpy()

for x in data1:
    myVector = []
    for y in x:
        myVector.append(y)
    provisionSigfoxDevice(myVector[0]) # whe just need the name to provision








