import requests
from requests.structures import CaseInsensitiveDict

def geolocate(mac1,mac2):
    urlNoKey = "https://www.googleapis.com/geolocation/v1/geolocate?key="
    key="" # to add a key
    url = urlNoKey+key
    headers = CaseInsensitiveDict()
    headers["Accept"] = "application/json"
    headers["Content-Type"] = "application/json"
    string = '{"considerIp": "false","wifiAccessPoints": [{"macAddress": "'+mac1+'","signalStrength": -54 ,"signalToNoiseRatio": 0},'
    string += '{"macAddress": "'+mac1+'","signalStrength": -54,"signalToNoiseRatio": 0}]}'        
    
    # to uncoment when we got a key
    #resp = requests.post(url, headers=headers, data=data)
   # print(string)
    #print("Sended:")
    #print(resp.status_code)
