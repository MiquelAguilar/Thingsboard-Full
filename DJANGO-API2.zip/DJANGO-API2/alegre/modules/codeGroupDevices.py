import requests
import json
from requests.auth import HTTPDigestAuth
import paho.mqtt.client as mqtt
from modules.sigfoxDevice import *


# input void
# output token a string value that is the login token
# sends a mqtt message
def getToken():
    basicUrL = "https://192.168.10.69:8080"
    api_url = basicUrL+"/api/auth/login"

    # headers for the token
    headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
    # data to login
    data = '{"username":"fivecomm@admin.com","password":"Fivecomm2022."}' # to change
    # data = '{"username":"ialegreDemo@alegre.com","password":"ialegreDemo"}' # to change
    response = requests.post(api_url,headers=headers,data=data, verify=False)
    token = response.json()['token']
    return token

# input msg as the message to send and token as the token of the device
# output void
# sends a mqtt message
def sendData(msg, token):
    #host = '192.168.10.100'
    host = '192.168.10.69'
    ACCESS_TOKEN = token
    #print(msg)
    client = mqtt.Client()

    # Set access token
    client.username_pw_set(ACCESS_TOKEN)

    # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
    client.connect(host, 1883, 60)

    client.loop_start()

    try:
        # print(msg)
        #client.publish('v1/devices/Alegre/location', msg, 1)
        client.publish('v1/devices/Sigfox/telemetry', msg, 1)
        # print("sended")
    except KeyboardInterrupt:
        pass

    client.loop_stop()
    client.disconnect()

# input basicUrl and head for https request
# output int
# sends a mqtt message
def obtainNumFORD(basicUrL,head):

    api_url = basicUrL+"/api/customers?pageSize=100&page=0" # GET all customers
    res = requests.get(api_url,headers=head, verify=False)
    customers = res.json()  # All customers
    # num_customers = len(customers['data'])

    devicesCustomer = []
    devicesOnFord = 0
    numberPageDevices = 0
    noTotalDevices = True

    for customer_i in range(len(customers['data'])):
        # while noTotalDevices:
            api_url = basicUrL+"/api/customer/"+customers['data'][customer_i]['id']['id']+"/devices?pageSize=10000&page=" + str(numberPageDevices)
            res = requests.get(api_url,headers=head, verify=False)
            devicesCustomer += res.json()['data']           # Todos los dispositivos que tienen clientes asignados (TODOS LOS CLIENTES)
            # if int(res.json()['totalPages']) == numberPageDevices:
            #     noTotalDevices = False
            #     print("total de hojas: ",res.json()['totalPages'])
            # else:
            #     numberPageDevices += 1
    
    for device_i in range(len(devicesCustomer)):       
        api_url = basicUrL+"/api/plugins/telemetry/DEVICE/"+devicesCustomer[device_i]['id']['id']+"/values/timeseries"  # Telemetría de todos los dispositivos
        res = requests.get(api_url,headers=head, verify=False)
        try:   
            Location = res.json()['Location'][0]['value']
        except:
            Location = ""
            
        if Location == "FORD":
            devicesOnFord += 1

    return devicesOnFord

# input basicUrl and head for https request
# output int
# sends a mqtt message
def obtainNumYANFENG(basicUrL,head):

    api_url = basicUrL+"/api/customers?pageSize=100&page=0" # GET all customers
    res = requests.get(api_url,headers=head, verify=False)
    customers = res.json()  # All customers
    # num_customers = len(customers['data'])

    devicesCustomer = []
    devicesOnAlegre = 0
    numberPageDevices = 0
    noTotalDevices = True

    for customer_i in range(len(customers['data'])):
        # while noTotalDevices:
            api_url = basicUrL+"/api/customer/"+customers['data'][customer_i]['id']['id']+"/devices?pageSize=10000&page=" + str(numberPageDevices)
            res = requests.get(api_url,headers=head, verify=False)
            devicesCustomer += res.json()['data']           # Todos los dispositivos que tienen clientes asignados (TODOS LOS CLIENTES)
            # if int(res.json()['totalPages']) == numberPageDevices:
            #     noTotalDevices = False
            #     print("total de hojas: ",res.json()['totalPages'])
            # else:
            #     numberPageDevices += 1
    
    for device_i in range(len(devicesCustomer)):       
        api_url = basicUrL+"/api/plugins/telemetry/DEVICE/"+devicesCustomer[device_i]['id']['id']+"/values/timeseries"  # Telemetría de todos los dispositivos
        res = requests.get(api_url,headers=head, verify=False)
        try:   
            Location = res.json()['Location'][0]['value']
        except:
            Location = ""
            
        if Location == "YANFENG":
            devicesOnAlegre += 1

    return devicesOnAlegre


# input basicUrl and head for https request
# output int
# sends a mqtt message
def obtainMaxBoxesInSite(basicUrL,head):
    api_url = basicUrL+"/api/plugins/telemetry/DEVICE/f21ac060-880b-11ec-ad83-efa322347cd8/values/timeseries"  #DEVICE/....aqui el ID del dispositivo..../values/timeseries
    res = requests.get(api_url,headers=head, verify=False)
    # print(res.json())
    return res.json()['NumberAlarmBoxes'][0]['value']


# input basicUrl and head for https request
# output void
# sends a mqtt message
def maximunNumberBoxesSite():
    basicUrL = "https://192.168.10.69:8080"
    token = getToken()
    token_group = "1m9uYTmQqIjCUxiWb16f"
    head = {'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}
    if (int(obtainNumYANFENG(basicUrL,head)) > int(obtainMaxBoxesInSite(basicUrL,head))):
        msg={"DaysOnZone":"YANFENGTrue"}
        # printIntro()
        print("Message to DeviceGroup:")
        sendDataToThingsboardTest(str(msg), token_group)
    if (int(obtainNumFORD(basicUrL,head)) > int(obtainMaxBoxesInSite(basicUrL,head))):
        msg={"DaysOnZone":"FORDTrue"}
        # printIntro()
        print("Message to DeviceGroup:")
        sendDataToThingsboardTest(str(msg), token_group)
