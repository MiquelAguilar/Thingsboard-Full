import requests
import paho.mqtt.client as mqtt
from modules.sigfoxDevice import *

# input void
# output token a string value that is the login token
# sends a mqtt message
def getToken():
    basicUrL = "https://192.168.10.69:8080"
    api_url = basicUrL+"/api/auth/login"

    # headers for the token
    headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
    # data to login
    data = '{"username":"fivecomm@admin.com","password":"Fivecomm2022."}' # to change
    response = requests.post(api_url,headers=headers,data=data, verify=False)
    token = response.json()['token']
    return token


def getInfoThresholdHot(): # Get the widget threshold hot 
    token = getToken() 
    basicUrL = "https://192.168.10.69:8080"
    head = {'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}
    api_url = basicUrL+"/api/plugins/telemetry/DEVICE/f21ac060-880b-11ec-ad83-efa322347cd8/values/timeseries"  # Telemetría de Device
    res = requests.get(api_url,headers=head, verify=False)
    return res.json()['hotAlarm'][0]['value']

def getInfoThresholdCold(): # Get the widget threshold hot
    token = getToken() 
    basicUrL = "https://192.168.10.69:8080"
    head = {'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}
    api_url = basicUrL+"/api/plugins/telemetry/DEVICE/f21ac060-880b-11ec-ad83-efa322347cd8/values/timeseries"  # Telemetría de Device
    res = requests.get(api_url,headers=head, verify=False)
    return res.json()['coldAlarm'][0]['value']

def modify_temperature_threshold(msg2): # Send to thingboard the news temperature threshold 
    threshold_hot = getInfoThresholdHot()
    threshold_cold = getInfoThresholdCold()
    msg={',"Cold_threshold_temperature"':threshold_cold,'"Hot_threshold_temperature"':threshold_hot}
    msg3 = str(msg2).replace("}","")
    msg3 = str(msg3)+str(msg)[2:]
    if msg3.find("'") != -1:
        msg3 = msg3.replace("'","")
    if(str(msg3)[2:4] == "ts"):
        msg3 += "}"     
    return msg3