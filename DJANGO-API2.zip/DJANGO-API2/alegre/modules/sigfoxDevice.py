import paho.mqtt.client as mqtt

def sendDataToThingsboard(msg, token):
    sendDataToThingsboardTest(msg,token)
    THINGSBOARD_HOST = '192.168.10.100'
    ACCESS_TOKEN = token
    #print(msg)
    client = mqtt.Client()

    # Set access token
    client.username_pw_set(ACCESS_TOKEN)

    # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
    client.connect(THINGSBOARD_HOST, 1883, 60)

    client.loop_start()

    try:
        # print(msg)
        client.publish('v1/devices/Sigfox/telemetry', msg, 1)
        # print("sended")
    except KeyboardInterrupt:
        pass

    client.loop_stop()
    client.disconnect()

def sendDataToThingsboardTest(msg, token):
    THINGSBOARD_HOST = '192.168.10.69'
    ACCESS_TOKEN = token
    #print(msg)
    client = mqtt.Client()

    # Set access token
    client.username_pw_set(ACCESS_TOKEN)

    # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
    client.connect(THINGSBOARD_HOST, 1883, 60)

    client.loop_start()

    try:
        # print("Message is: ",msg)
        client.publish('v1/devices/Sigfox/telemetry', msg, 1)
        print("Message is: ",msg," - sended")
        # print("sended")
    except KeyboardInterrupt:
        pass

    client.loop_stop()
    client.disconnect()


# input msg as the message to send and token as the token of the device
# output void
# sends a mqtt message
def sendData(msg, token):
    host = '192.168.10.69'
    ACCESS_TOKEN = token
    client = mqtt.Client()
    # Set access token
    client.username_pw_set(ACCESS_TOKEN)
    # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
    client.connect(host, 1883, 60)

    client.loop_start()

    try:
        print(msg)
        client.publish('v1/devices/Sigfox/telemetry', msg, 1)
        print("sended")
    except KeyboardInterrupt:
        pass

    client.loop_stop()
    client.disconnect()

# input void
# output token a string value that is the login token
# sends a mqtt message
# def getTokenDemo():
#     basicUrL = "http://192.168.10.69:8080"
#     api_url = basicUrL+"/api/auth/login"

#     # headers for the token
#     headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
#     # data to login
#     data = '{"username":"ialegreDemo@alegre.com","password":"ialegreDemo"}' # to change
#     response = requests.post(api_url,headers=headers,data=data)
#     token = response.json()['token']
#     return token