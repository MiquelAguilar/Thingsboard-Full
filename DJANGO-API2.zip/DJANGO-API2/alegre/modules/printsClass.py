class printClass:
    def __init__(self,check):
        self._check = check

    def printIntro(self):
        if self._checkIntro:
            print("\n")

    def printLowBar(self):
        if self._checkLowBar:
            print("_____________________________________________________________________________________")

    def printVar(self,var):
        if self._checkVar:
            print("Value of variabol",var.name)

    def hazmelo(self):
        self._checkIntro =  self._check and True
        self._checkLowBar = self._check and True
        self._checkVar =    self._check and True