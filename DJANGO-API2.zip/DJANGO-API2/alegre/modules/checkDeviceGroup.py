import requests
import json
from requests.auth import HTTPDigestAuth

# input void
# output token a string value that is the login token
# sends a mqtt message
def getToken():
    basicUrL = "https://192.168.10.69:8080"
    api_url = basicUrL+"/api/auth/login"

    # headers for the token
    headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
    # data to login
    data = '{"username":"ialegreDemo@alegre.com","password":"ialegreDemo"}' # to change
    response = requests.post(api_url,headers=headers,data=data, verify=False)
    token = response.json()['token']
    return token


def reset():
    basicUrL = "https://192.168.10.69:8080"
    token = getToken() 
    head = {'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}
    api_url = basicUrL+"/api/plugins/telemetry/DEVICE/f21ac060-880b-11ec-ad83-efa322347cd8/values/timeseries"  #DEVICE/....aqui el ID del dispositivo..../values/timeseries
    res = requests.get(api_url,headers=head, verify=False)
    resetStatus =  res.json()['reset'][0]['value'] == "true"
    print(resetStatus)
    return bool(resetStatus)

