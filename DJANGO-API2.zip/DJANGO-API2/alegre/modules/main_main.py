import time

from resetDemoAlarms import *
from checkDeviceGroup import *

t = 1
lock = True
while True:
    if reset() == lock :
        resetAlarms()
        lock = not lock
    time.sleep(t)