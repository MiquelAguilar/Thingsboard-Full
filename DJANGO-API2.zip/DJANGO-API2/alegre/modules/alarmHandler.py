import requests
import json
from requests.auth import HTTPDigestAuth
import paho.mqtt.client as mqtt
from modules.sigfoxDevice import *

# input void
# output token a string value that is the login token
# sends a mqtt message
def getToken():
    basicUrL = "https://192.168.10.69:8080"
    api_url = basicUrL+"/api/auth/login"

    # headers for the token
    headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
    # data to login
    data = '{"username":"ialegreDemo@alegre.com","password":"ialegreDemo"}' # to change
    response = requests.post(api_url,headers=headers,data=data, verify=False)
    token = response.json()['token']
    return token


def alarmControl():
    basicUrL = "https://192.168.10.69:8080"

    token = getToken() 
    # headers for getting all the alarms
    head = {'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}
    # headers for setting up the alarm
    fHeaders = {'Content-Type':'application/json', 'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}

    # obtained the credentials for every https rest petition
    noTotalALarms = True
    numberPage=0
    alarmData = []
    while noTotalALarms:
        # the url to use
        api_url = basicUrL+"/api/alarms?pageSize=100&page="+ str(numberPage) 
        res = requests.get(api_url,headers=head, verify=False)
        alarmData += res.json()['data']
        if int(res.json()['totalPages']) == numberPage:
            noTotalALarms = False
        else:
            numberPage += 1
    #every alarmData element is one alarm(intern variable is a dict) so we can search ['type']       
    vecPos = 0
    contAlegre = 0
    contFord = 0
    contYanFeng = 0

    #checking the number of coincidences
    while vecPos != len(alarmData):
        if alarmData[vecPos]['type'] == 'Days on Zone' and alarmData[vecPos]['status'] == 'ACTIVE_UNACK':

            device_id = alarmData[vecPos]['originator']['id']
            api_url = basicUrL+"/api/plugins/telemetry/DEVICE/"+str(device_id)+"/values/timeseries"
            res = requests.get(api_url,headers=head, verify=False)
            locationDevice = res.json()['Location'][0]['value']
            if str(locationDevice) == "ALEGRE":
                contAlegre += 1
            elif  str(locationDevice) == "FORD":
                contFord += 1

            elif  str(locationDevice) == "YANFENG":
                contYanFeng += 1

        vecPos += 1

    # we should set up the alarm with the api
   
    # doing with mqtt
    maxNumberAlarm = 3
    mqttToken = '8WPZTj2jpzVkeWEyrSwg'
    if contAlegre >= maxNumberAlarm:
        msg={"DaysOnZone":str(locationDevice)+"True"}
        sendData(str(msg),mqttToken)
    if contFord >= maxNumberAlarm:
        msg={"DaysOnZone":str(locationDevice)+"True"}
        sendData(str(msg),mqttToken)
    if contYanFeng >= maxNumberAlarm:
        msg={"DaysOnZone":str(locationDevice)+"True"}
        sendData(str(msg),mqttToken)      
