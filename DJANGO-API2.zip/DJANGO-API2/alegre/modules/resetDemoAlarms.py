import requests
import json
from requests.auth import HTTPDigestAuth
import paho.mqtt.client as mqtt
from modules.sigfoxDevice import *

# input void
# output token a string value that is the login token
# sends a mqtt message
def getToken():
    basicUrL = "https://192.168.10.69:8080"
    api_url = basicUrL+"/api/auth/login"

    # headers for the token
    headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
    # data to login
    data = '{"username":"ialegreDemo@alegre.com","password":"ialegreDemo"}' # to change
    response = requests.post(api_url,headers=headers,data=data)
    token = response.json()['token']
    return token


def obtainNumAlegre(basicUrL,head):

    api_url = basicUrL+"/api/customers?pageSize=100&page=0" # GET all customers
    res = requests.get(api_url,headers=head, verify=False)
    customers = res.json()  # All customers
    # num_customers = len(customers['data'])

    devicesCustomer = []
    devicesOnAlegre = 0
    numberPageDevices = 0
    noTotalDevices = True

    for customer_i in range(len(customers['data'])):
        # while noTotalDevices:
            api_url = basicUrL+"/api/customer/"+customers['data'][customer_i]['id']['id']+"/devices?pageSize=10000&page=" + str(numberPageDevices)
            res = requests.get(api_url,headers=head, verify=False)
            devicesCustomer += res.json()['data']           # Todos los dispositivos que tienen clientes asignados (TODOS LOS CLIENTES)
            # if int(res.json()['totalPages']) == numberPageDevices:
            #     noTotalDevices = False
            #     print("total de hojas: ",res.json()['totalPages'])
            # else:
            #     numberPageDevices += 1
    
    for device_i in range(len(devicesCustomer)):       
        api_url = basicUrL+"/api/plugins/telemetry/DEVICE/"+devicesCustomer[device_i]['id']['id']+"/values/timeseries"  # Telemetría de todos los dispositivos
        res = requests.get(api_url,headers=head, verify=False)
        try:   
            Location = res.json()['Location'][0]['value']
        except:
            Location = ""
            
        if Location == "ALEGRE":
            devicesOnAlegre += 1

    return devicesOnAlegre


def obtainMinBoxesAlegre(basicUrL,head):
    api_url = basicUrL+"/api/plugins/telemetry/DEVICE/f21ac060-880b-11ec-ad83-efa322347cd8/values/timeseries"  #DEVICE/....aqui el ID del dispositivo..../values/timeseries
    res = requests.get(api_url,headers=head, verify=False)
    print(res.json())
    return res.json()['NumberDevicesAlegre'][0]['value']

def resetAlarms():
    #basicUrL = "https://192.168.10.100:8080"
    basicUrL = "https://192.168.10.69:8080"


    token = getToken() 
    # headers for getting all the alarms
    # print(token)
    head = {'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}
    # headers for setting up the alarm
    fHeaders = {'Content-Type':'application/json', 'Accept': 'application/json','X-Authorization': 'Bearer$' + str(token)}

    phead = {'Content-Type':'application/json','X-Authorization': 'Bearer$' + str(token)}

    # obtained the credentials for every https rest petition
    noTotalALarms = True
    numberPage=0
    alarmData = []
    while noTotalALarms:
        # the url to use
        api_url = basicUrL+"/api/alarms?pageSize=100&page="+ str(numberPage) 
        # print(head)
        res = requests.get(api_url,headers=head, verify=False)
        # print(res)
        alarmData += res.json()['data']

        if int(res.json()['totalPages']) == numberPage:
            noTotalALarms = False
        else:
            numberPage += 1
    #every alarmData element is one alarm(intern variable is a dict) so we can search ['type']       
    # print(alarmData[1])
    vecPos = 0
    contAlegre = 0
    contFord = 0
    contYanFeng = 0

    #checking the number of coincidences
    while vecPos != len(alarmData):
        # should check location and status
        #print(str(alarmData[vecPos]['type'])+str(alarmData[vecPos]['status']))
        if alarmData[vecPos]['type'] == 'Days on Zone' and alarmData[vecPos]['status'] == 'ACTIVE_UNACK':

            device_id = alarmData[vecPos]['originator']['id']
            api_url = basicUrL+"/api/plugins/telemetry/DEVICE/"+str(device_id)+"/values/timeseries"
            res = requests.get(api_url,headers=head, verify=False)
            locationDevice = res.json()['Location'][0]['value']
            if str(locationDevice) == "ALEGRE":
                contAlegre += 1
            elif  str(locationDevice) == "FORD":
                contFord += 1

            elif  str(locationDevice) == "YANFENG":
                contYanFeng += 1

        vecPos += 1





    devicesOnAlegre = obtainNumAlegre(basicUrL,head)        # Numero de Smart Boxes en Alegre
    minBoxesAlegre = obtainMinBoxesAlegre(basicUrL,head)    # Numero de Smart Boxes minimas en Alegre
    print("Numnero minimo de dispotivios en Alegre: ",minBoxesAlegre," y Dispositivos en Alegre actualmente: ",devicesOnAlegre)

    #A PARTIR DE AQUI, TODOS LOS MENSAJES QUE QUEREMOS SIMULADOS PARA LA DEMO

    #mqttToken = '8WPZTj2jpzVkeWEyrSwg'

    # ALARMA - FEW BOXES ALEGRE
    mqttToken = '1m9uYTmQqIjCUxiWb16f'      #Token DeviceGroup
    if int(devicesOnAlegre) < int(minBoxesAlegre):
        msg={"MinimunBoxesAlegre":"True"}
        sendData(str(msg),mqttToken)
    else:
        msg={"MinimunBoxesAlegre":"False"}
        sendData(str(msg),mqttToken)

        # TOKENS
    token_yangfeng = 'ampIKUuhUXVUXBIDc9ic'
    token_alegre = 'mQf39G8RypWcKdxBkJ5Q'
    token_ford = 'bXOx55PHVh31VOOA3Ixd'
    token_unknown = 'znahVcTT91Ju0KCxOthY'

    # ALARMA LOST

        # msg={"MinimunBoxesAlegre":"True"}
        # sendData(str(msg),mqttToken)

    # ZONE CLOSED ALARM

    # ALARM UNKNONW ZONE

    # ALARM LOW BATTERY ALARM -- CRITIC ALARM BATTERY
    msg={"battery":"2,0V - Alerta Batería Baja","temperature":5, "info_sensor":"Desplegado OFF","latitude":39.32160,"longitude":-0.42412}
    sendData(str(msg),token_yangfeng)

    msg={"battery":"1,9V - Alerta Batería Critica","temperature":25, "info_sensor":"Desplegado ON","latitude":39.39298,"longitude":-0.39908}
    sendData(str(msg),token_alegre)

    msg={"battery":"3,0V - OK","temperature":45, "info_sensor":"Desplegado OFF","latitude":39.31592,"longitude":-0.41302,"DaysOnZone":"FORDTrue"}
    sendData(str(msg),token_ford)

    msg={"battery":"3,0V - OK","temperature":45, "info_sensor":"Desplegado OFF","daysZone":4,"daysZoneClosed":3,"latitude":39.33884,"longitude":-0.44765}
    sendData(str(msg),token_unknown)

    # ALARMAS QUE SALTAN:
    #       - HOT TEMPERATURE
    #       - COLD TEMPERATURE
    #       - FEW BOXES ALEGRE
    #       - LOW BATTERY ALARM
    #       - CRITICAL BATTERY ALARM
    #       - LOST
    #       - DAYS ON ZONE + CLOSED
