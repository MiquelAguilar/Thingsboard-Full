from modules.sigfoxDevice import *


def obtainNumAlegre(basicUrL,head):

    api_url = basicUrL+"/api/customers?pageSize=100&page=0" # GET all customers
    res = requests.get(api_url,headers=head)
    customers = res.json()  # All customers
    # num_customers = len(customers['data'])

    devicesCustomer = []
    devicesOnAlegre = 0
    numberPageDevices = 0
    noTotalDevices = True

    for customer_i in range(len(customers['data'])):
        # while noTotalDevices:
            api_url = basicUrL+"/api/customer/"+customers['data'][customer_i]['id']['id']+"/devices?pageSize=10000&page=" + str(numberPageDevices)
            res = requests.get(api_url,headers=head)
            devicesCustomer += res.json()['data']           # Todos los dispositivos que tienen clientes asignados (TODOS LOS CLIENTES)
            # if int(res.json()['totalPages']) == numberPageDevices:
            #     noTotalDevices = False
            #     print("total de hojas: ",res.json()['totalPages'])
            # else:
            #     numberPageDevices += 1
    
    for device_i in range(len(devicesCustomer)):       
        api_url = basicUrL+"/api/plugins/telemetry/DEVICE/"+devicesCustomer[device_i]['id']['id']+"/values/timeseries"  # Telemetría de todos los dispositivos
        res = requests.get(api_url,headers=head)
        try:   
            Location = res.json()['Location'][0]['value']
        except:
            Location = ""
            
        if Location == "ALEGRE":
            devicesOnAlegre += 1

    return devicesOnAlegre


def obtainMinBoxesAlegre(basicUrL,head):
    api_url = basicUrL+"/api/plugins/telemetry/DEVICE/f21ac060-880b-11ec-ad83-efa322347cd8/values/timeseries"  #DEVICE/....aqui el ID del dispositivo..../values/timeseries
    res = requests.get(api_url,headers=head)
    return res.json()['NumberDevicesAlegre'][0]['value']

def checkMinDevicesAlegre():
    deviceGroupToken = '1m9uYTmQqIjCUxiWb16f'

    if int(obtainNumAlegre(basicUrL,head) ) < int(obtainMinBoxesAlegre(basicUrL,head)):    # Numero de Smart Boxes en Alegre < Numero de Smart Boxes minimas en Alegre
        msg={"MinimunBoxesAlegre":"True"}
        sendData(str(msg),deviceGroupToken)
    else:
        msg={"MinimunBoxesAlegre":"False"}
        sendData(str(msg),deviceGroupToken)
