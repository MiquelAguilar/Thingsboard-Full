from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import JSONParser

from datetime import datetime, timedelta
from rest_framework.permissions import IsAuthenticated
import mysql.connector
from django.http import HttpResponse, JsonResponse
import os, json

from paho.mqtt.client import Client
from json import dumps, loads
import mysql.connector

RESULT_CODES = {
    1: "incorrect protocol version",
    2: "invalid client identifier",
    3: "server unavailable",
    4: "bad username or password",
    5: "not authorised",
    }
    
def collect_required_data():
    config = {}
    config["host"] = '192.168.10.100'
    config["port"] = 1883
    config["provision_device_key"] = 'dzz6hwsh8p4e9f1tyx5t'
    config["provision_device_secret"] = '6e9aeav7zdovc4i56oy0'
    device_name = "test_mario"
    config["pwd"]=""
    if device_name:
        config["device_name"] = device_name
    return config

class ProvisionClient(Client):
    PROVISION_REQUEST_TOPIC = "/provision/request"
    PROVISION_RESPONSE_TOPIC = "/provision/response"

    def __init__(self, host, port, provision_request):
        super().__init__()
        self._host = host
        self._port = port
        self._username = "provision"
        self.on_connect = self.__on_connect
        self.on_message = self.__on_message
        self.__provision_request = provision_request

    def __on_connect(self, client, userdata, flags, rc):  # Callback for connect
        if rc == 0:
            print("[Provisioning client] Connected to ThingsBoard ")
            client.subscribe(self.PROVISION_RESPONSE_TOPIC)  # Subscribe to provisioning response topic
            provision_request = dumps(self.__provision_request)
            print("[Provisioning client] Sending provisioning request %s" % provision_request)
            client.publish(self.PROVISION_REQUEST_TOPIC, provision_request)  # Publishing provisioning request topic
        else:
            print("[Provisioning client] Cannot connect to ThingsBoard!, result: %s" % RESULT_CODES[rc])

    def __on_message(self, client, userdata, msg):
        decoded_payload = msg.payload.decode("UTF-8")
        print("[Provisioning client] Received data from ThingsBoard: %s" % decoded_payload)
        decoded_message = loads(decoded_payload)
        provision_device_status = decoded_message.get("status")
        if provision_device_status == "SUCCESS":
            self.__save_credentials(decoded_message["credentialsValue"])            
        else:
            print("[Provisioning client] Provisioning was unsuccessful with status %s and message: %s" % (provision_device_status, decoded_message["errorMsg"]))
        self.disconnect()

    # def on_disconnect(self, userdata, rc):
    #     print("client disconnected ok")
    #     self.on_disconnect = on_disconnect
    #     self.disconnect()

    def provision(self):
        print("[Provisioning client] Connecting to ThingsBoard (provisioning client)")
        self.__clean_credentials()
        self.connect(self._host, self._port, 60)
        self.loop_forever()

    def get_new_client(self):
        client_credentials = self.__get_credentials()
        new_client = None
        if client_credentials:
            new_client = Client()
            new_client.username_pw_set(client_credentials)
            print("[Provisioning client] Read credentials from file.")
        else:
            print("[Provisioning client] Cannot read credentials from file!")
        return new_client

    @staticmethod
    def __get_credentials():
        new_credentials = None
        try:
            with open("credentials", "r") as credentials_file:
                new_credentials = credentials_file.read()
                config["pwd"] = new_credentials
        except Exception as e:
            print(e)
        return new_credentials

    @staticmethod
    def __save_credentials(credentials):
        with open("credentials", "w") as credentials_file:
            credentials_file.write(credentials)

    @staticmethod
    def __clean_credentials():
        open("credentials", "w").close()

def on_tb_connected(client, userdata, flags, rc):  # Callback for connect with received credentials
    if rc == 0:
        print("[ThingsBoard client] Connected to ThingsBoard with credentials: %s" % client._username.decode())
    else:
        print("[ThingsBoard client] Cannot connect to ThingsBoard!, result: %s" % RESULT_CODES[rc])


class ImportSigfox(APIView):
    permission_classes = (IsAuthenticated,) 

    

    def post(self, request):

        def makingLogsDir(directory):
            if not os.path.isdir(directory):
                try:
                        os.makedirs(directory)
                except OSError:
                        pass
        directory = "logs"
        makingLogsDir(directory)
        try:

            content = {'message': 'Error'}

            # body_unicode = request.body.decode('utf-8')
            # requestParsed = body_unicode.replace('\n', '')
            
            dataJSON = JSONParser().parse(request)
            
            if dataJSON != '':
                # #data base conection
                mydbConnector = mysql.connector.connect(
                host="localhost", 
                user="adminIOT",
                password="2zKxspRuwdTgiABEo9",
                database="iotPlatform",
                )

                #generating the cursor of the database
                myCursor = mydbConnector.cursor()

                messageType = dataJSON["messageType"]
                device = dataJSON["device"]
                deviceType = dataJSON["deviceType"]
                sequencyNumber = dataJSON["sequencyNumber"]
                time = dataJSON["time"]
                data = dataJSON["data"]
                operator = dataJSON["operator"]
                fixedLat = dataJSON["fixedLat"]
                fixedLng = dataJSON["fixedLng"]

                computedLocation = dataJSON["computedLocation"]
                computedLocationParsed = json.dumps(computedLocation[0])
                computedLocationJSON = json.loads(computedLocationParsed)
                lat = computedLocationJSON["lat"]
                lng = computedLocationJSON["lng"]
                radius = computedLocationJSON["radius"]
                source = computedLocationJSON["source"]
                status = computedLocationJSON["status"]

                countryCode = dataJSON["countryCode"]
                linkQuality = dataJSON["linkQuality"]


                sql = "INSERT INTO `sigfoxDevice`(`messageType`, `device`, `deviceType`, `sequencyNumber`, `time`, `data`, `operator`, `fixedLat`, `fixedLng`, `lat`, `lng`, `radius`, `source`, `status`, `countryCode`, `linkQuality`) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
                val = messageType, device, deviceType, sequencyNumber, time, data, operator, fixedLat, fixedLng, lat, lng, radius, source, status, countryCode, linkQuality
                myCursor.execute(sql, val)
                #### Este comentario es otra opcion de hacerlo
                # val ="INSERT INTO `sigfoxDevice`(`hexaValue`) VALUES('%s');"%requestParsed
                # myCursor.execute(val)
                ####
                mydbConnector.commit()

                # os.system('python3 /root/DJANGO_API/sigfox_api/format_sigfox.py')

                ###### Aqui empieza la integración del dispositivo en Thingsboard
                config = collect_required_data()

                THINGSBOARD_HOST = config["host"]  # ThingsBoard instance host
                THINGSBOARD_PORT = config["port"]  # ThingsBoard instance MQTT port

                PROVISION_REQUEST = {"provisionDeviceKey": config["provision_device_key"],  # Provision device key, replace this value with your value from device profile.
                                    "provisionDeviceSecret": config["provision_device_secret"],  # Provision device secret, replace this value with your value from device profile.
                                    }

                myCursor = mydbConnector.cursor()
                myCursor.execute("SELECT name FROM sigfoxCredentials WHERE `name`= '%s';" %(config["device_name"]))

                device_exists = 0
                for row in myCursor.fetchall():
                    device_exists = row[0]

                if device_exists:
                    print("Por hacer")
                else:
                    PROVISION_REQUEST["deviceName"] = config["device_name"]
                    provision_client = ProvisionClient(THINGSBOARD_HOST, THINGSBOARD_PORT, PROVISION_REQUEST)
                    provision_client.provision()  # Request provisioned data
                    tb_client = provision_client.get_new_client()  # Getting client with provisioned data
                    if tb_client:
                        print('Fin')
                        sql = "INSERT INTO `sigfoxCredentials`(`name`, `token`) VALUES (%s, %s);"
                        val = (config["device_name"], config["pwd"])
                        myCursor.execute(sql, val)
                        mydbConnector.commit()

                        topyc = "v1/devices/Sigfox/telemetry"
                        message = {
                                   "messageType": '%s',
                                   "device":'%s',
                                   "deviceType":'%s',
                                   "sequencyNumber":'%s',
                                   "time":'%s',
                                   "data":'%s',
                                   "operator":'%s',
                                   "fixedLat":'%s',
                                   "fixedLng":'%s',
                                   "lat":'%s',
                                   "lng":'%s',
                                   "radius":'%s',
                                   "source":'%s',
                                   "status":'%s',
                                   "countryCode":'%s',
                                   "linkQuality":'%s'
                                   } %(messageType, device, deviceType, sequencyNumber, time, data, operator, fixedLat, fixedLng, lat, lng, radius, source, status, countryCode, linkQuality)

                        tb_client.publish(topyc, message)
                        tb_client.disconnect()

                    else:
                        print("Client was not created!")

                ########## Aqui termina ###################

                content = {'message': 'Data imported'}
                # return Response(content)
            return Response(content)

        except:
            logFile = open("logs/backendErrors.txt", "ab")
            cDate = datetime.now()           
            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            textToWrite = b"Principal thread error\n"
            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            logFile.close()
            print(textToWrite.decode('ASCII'))    