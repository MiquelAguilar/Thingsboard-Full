from django.db import models

# Create your models here.

# class sigfoxJsonData(models.Model):
#     device = models.CharField(max_length=8)
#     time = models.IntegerField()
#     data = models.CharField(max_length=100)
#     seqNumber = models.IntegerField()
#     lqi = models.CharField(max_length=20)
#     linkQuality = models.IntegerField()
#     fixedLat = models.DecimalField()
#     fixedLng = models.DecimalField()
#     operatorName = models.CharField(max_length=100)
#     contryCode = models.IntegerField()
#     duplicates = models.duplicate()
#     computedLocation = models.computedLocations()

# class duplicate(models.Model):
#     bsld = models.CharField(max_length=20)
#     nbRep = models.IntegerField()
#     rssi = models.DecimalField()
#     snr = models.DecimalField()

# class computedLocation(models.Model):
#     lat = models.DecimalField()
#     lng = models.DecimalField()
#     radius = models.IntegerField()
#     source = models.IntegerField()
#     status = models.IntegerField()
