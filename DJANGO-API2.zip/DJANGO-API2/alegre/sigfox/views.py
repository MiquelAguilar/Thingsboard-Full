from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import JSONParser

from datetime import datetime, timedelta
from rest_framework.permissions import IsAuthenticated
import mysql.connector
from django.http import HttpResponse, JsonResponse
import os, json

from modules.sigfoxDevice import *
from modules.provisioningSigfox import *
from modules.format_sigfox import *
from modules.macCheck import *
from modules.alarmHandler import *
from modules.putThresholdTemperatureAlltest import *
from modules.codeGroupDevices import *
from modules.printsClass import *

# to eliminate warnings
import urllib3
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
# to eliminate warnings 

class ImportSigfox(APIView):
    permission_classes = (IsAuthenticated,) 

    def post(self, request):

        def makingLogsDir(directory):
            if not os.path.isdir(directory):
                try:
                        os.makedirs(directory)
                except OSError:
                        pass
        directory = "logs"
        makingLogsDir(directory)
        try:
            printer = printClass(True) # True print, False not print
            printer.hazmelo()

            content = {'message': 'Error'}

            # body_unicode = request.body.decode('utf-8')
            # requestParsed = body_unicode.replace('\n', '')

            f = open("inputRaw.txt", "a")
            # print("antesDe")
            dataJSON = JSONParser().parse(request)
            #print("despuesDe")
            f.write(str(dataJSON))
            f.close()

            if dataJSON != '':
                # external alarm & report functions
                printer.printLowBar()
                maximunNumberBoxesSite()
                alarmControl()


                # end of external alarm & report functions
                
                # #data base conection
                mydbConnector = mysql.connector.connect(
                host="localhost", 
                user="adminIOT",
                password="2zKxspRuwdTgiABEo9",
                database="iotPlatform",
                )
 
                #generating the cursor of the database
                myCursor = mydbConnector.cursor()

                messageType = dataJSON["messageType"]
                device = dataJSON["device"]
                deviceType = dataJSON["deviceType"]
                sequenceNumber = dataJSON["sequencyNumber"]
                time = dataJSON["time"]
                data = dataJSON["data"] #mac
                print(data)
                operator = dataJSON["operator"]
                fixedLat = dataJSON["fixedLat"]
                fixedLng = dataJSON["fixedLng"]

                computedLocation = dataJSON["computedLocation"]
                computedLocationParsed = json.dumps(computedLocation[0])
                computedLocationJSON = json.loads(computedLocationParsed)
                lat = computedLocationJSON["lat"]
                lng = computedLocationJSON["lng"]
                radius = computedLocationJSON["radius"]
                source = computedLocationJSON["source"]
                status = computedLocationJSON["status"]

                countryCode = dataJSON["countryCode"]
                linkQuality = dataJSON["linkQuality"]
                # print("antes de insert")
                ####################################################################################3
                sql = "INSERT INTO `sigfoxMessages`(`messageType`, `device`, `deviceType`, `sequenceNumber`, `time`, `data`, `operator`, `fixedLat`, `fixedLng`, `lat`, `lng`, `radius`, `source`, `status`, `countryCode`, `linkQuality`) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
                val = messageType, device, deviceType, sequenceNumber, time, data, operator, fixedLat, fixedLng, lat, lng, radius, source, status, countryCode, linkQuality
                myCursor.execute(sql, val)
                #### Este comentario es otra opcion de hacerlo
                # val ="INSERT INTO `sigfoxDevice`(`hexaValue`) VALUES('%s');"%requestParsed
                # myCursor.execute(val)
                ####
                mydbConnector.commit()
                # print("mitadIns")

                #comprobamos que el dispositivo esté en la base de datos
                # print("antes del select views.py")
                sql = "SELECT token FROM sigfoxCredentials WHERE `name`= %s;"
                val = device
                myCursor.execute(sql, (val,))

                device_exists = 0
                for row in myCursor.fetchall():
                    device_exists = row[0]

                

                # msg = "{"+f'"device":"{device}","deviceType":"{deviceType}","sequenceNumber":{sequenceNumber},"time":{time},"data":"{data}","operator":"{operator}","fixedLat":{fixedLat},"latitude":{lat},"longitude":{lng},"radius":{radius},"source":{source},"status":{status},"countryCode":{countryCode},"linkQuality":{linkQuality}'+"}"
                # print("data:")
                # print(data)
                if device_exists:
                    # print("existe el dispositivo")
                    # print(data)
                    error, mode, message_type, temp_hum, battery, temperature, info_sensor = formatSigfoxData(device, data)
                    #print(str(macCheck(data,lat,lng)))
                    tmp = macCheck(data,lat,lng,source,status)
                    lat = float(tmp[0])
                    lng = float(tmp[1])
                    lock = bool(tmp[2])
                    try:

                        #print(f"select max(idMessage) from sigfoxMessages where device like '{device}';")

                        sql = "select max(idMessage) from sigfoxMessages where device like %s;"
                        val = (device,)
                        myCursor.execute(sql, val)
                        tmp = myCursor.fetchone()
                        idMessage = tmp[0]
                        #print("tmp")
                        #print(idMessage)
                        sql = "update iotPlatform.sigfoxMessages set mode = %s, message_type = %s, temp_hum=%s, battery=%s, temperature='%s', info_sensor=%s where idMessage = '%s';"
                        val = (mode, message_type, temp_hum, battery, int(temperature), info_sensor,idMessage)
                        #print(f'INSERT INTO iotPlatform.sigfoxData(mode, message_type, temp_hum, battery, temperature, info_sensor,idDevice)VALUES({mode}, {message_type}, {temp_hum}, {battery}, {temperature}, {info_sensor},{device});'
                        #print(f"update iotPlatform.sigfoxMessages set mode = {mode}, message_type = {message_type}, temp_hum={temp_hum}, battery={battery}, temperature={temperature}, info_sensor={info_sensor})where idMessage = {idMessage};")

                        myCursor.execute(sql, val)

                        mydbConnector.commit()
                    except:
                        print("Ha saltado el except: ",sys.exc_info())
                    if len(str(time))<=10:# cambiar el 4 de julio de 2490
                        time = str(time)+'0'*(13-len(str(time)))

                    if mode != "mac":
                        if error == False:
                            if info_sensor != "Null":
                                if source == 6 and status == 1:
                                    if radius < 1000: # maximum radius
                                        msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "info_sensor":"{info_sensor}", "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","latitude":{lat},"longitude":{float(lng)},"radius":{radius},"country":"{countryCode}"}}'+"}"

                                    else:
                                        msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "info_sensor":"{info_sensor}", "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","country":"{countryCode}"}}'+"}"

                                else:
                                    msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "info_sensor":"{info_sensor}", "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","country":"{countryCode}"}}'+"}"
                            else:
                                if source == 6 and status == 1:
                                    if radius < 1000: # maximum radius
                                        msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","latitude":{lat},"longitude":{float(lng)},"radius":{radius},"country":"{countryCode}"}}'+"}"
                                    else:
                                        msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","country":"{countryCode}"}}'+"}"
                                else:
                                    msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","country":"{countryCode}"}}'+"}"
                            print("This msg is NO MAC")
                            msg = modify_temperature_threshold(msg)  
                            # print(msg)     
                            sendDataToThingsboard(msg, device_exists)
                            # print("post send")
                        else:
                            print("post did not send")
                    elif mode == "macImport":
                        f = open("siteMacs.csv", "a")
                        f.write(dataImported[6:])
                        f.close()
                    else: # mac mode
                           if lock:
                                print("This msg is MAC")
                                msg = "{"+f'"device":"{device}","latitude":{lat},"longitude":{float(lng)},"sequenceNumber":{sequenceNumber}'+'}'
                                # print(msg)
                                msg = modify_temperature_threshold(msg)
                                sendDataToThingsboard(msg, device_exists)
                            #else:
                            #    print("macs sin source 6, status 1")    
                        # os.system('python3 /root/DJANGO_API/sigfox_api/format_sigfox.py')
                else:
                    # print("aprovisionando")
                    token = provisionSigfoxDevice(device)
                    print("provisioned")
                    error, mode, message_type, temp_hum, battery, temperature, info_sensor = formatSigfoxData(device, data)
                    print(f"select max(idMessage) from sigfoxMessages where device like '{device}';")
                    sql = "select max(idMessage) from sigfoxMessages where device like %s;"
                    val = (device,)
                    myCursor.execute(sql, val)
                    tmp = myCursor.fetchone()
                    idMessage = tmp[0]
                    print("tmp")
                    print(idMessage)
                    sql = "update iotPlatform.sigfoxMessages set mode = %s, message_type = %s, temp_hum=%s, battery='%s', temperature=%s, info_sensor=%s where idMessage = %s;"

                    #sql = "INSERT INTO iotPlatform.sigfoxMessages(mode, message_type, temp_hum, battery, temperature, info_sensor)VALUES(%s, %s, %s, %s, %s, %s)where idMessage like %s;"
                    val = (mode, message_type, temp_hum, battery, temperature, info_sensor,idMessage)
                    print(f"update iotPlatform.sigfoxMessages set mode = {mode}, message_type = {message_type}, temp_hum={temp_hum}, battery={battery}, temperature={temperature}, info_sensor={info_sensor} where idMessage = {idMessage};")

                    myCursor.execute(sql, val)
                    mydbConnector.commit()
                    if mode != "mac":
                        if error == False:
                            msg = "{"+f'"ts":{time}, "values":{{"device":"{device}","mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "info_sensor":"{info_sensor}", "sequenceNumber":{sequenceNumber},"data":"{data}","operator":"{operator}","latitude":{lat},"longitude":{float(lng)},"radius":{radius},"country":"{countryCode}"}}'+"}"
                            sendDataToThingsboard(msg, token)
                            print("post send")
                        else:
                            print("post did not send")

                ################################################
                # msg = "{"+f'"device":"{device}","deviceType":"{deviceType}","sequenceNumber":{sequenceNumber},"time":{time},"data":"{data}","operator":"{operator}","fixedLat":{fixedLat},"latitude":{lat},"longitude":{lng},"radius":{radius},"source":{source},"status":{status},"countryCode":{countryCode},"linkQuality":{linkQuality}'+"}"
                # sendDataToThingsboard(msg)

                content = {'message': 'Data imported'}
                # return Response(content)
                # alarmControl()
                # if reset():
                #     resetAlarms()


            return Response(content)

        except:
            logFile = open("logs/backendErrors.txt", "ab")
            cDate = datetime.now()           
            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            textToWrite = b"Principal thread error\n"
            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            logFile.close()
            print(textToWrite.decode('ASCII'))    
    
        