from django.urls import path
from sigfox import views

urlpatterns = [
    path('sigfox/', views.ImportSigfox.as_view(), name='sigfox'),
]