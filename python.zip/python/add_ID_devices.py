import mysql.connector
import requests
import paho.mqtt.client as mqtt

def getToken():
    basicUrL = "https://192.168.10.69:8080"
    api_url = basicUrL+"/api/auth/login"

    # headers for the token
    headers =  {'Content-Type':'application/json', 'Accept': 'application/json'}
    # data to login
    data = '{"username":"ialegreDemo@alegre.com","password":"ialegreDemo"}' # to change
    response = requests.post(api_url,headers=headers,data=data, verify=False)
    token = response.json()['token']
    return token

def sendData(msg, token):
    host = '192.168.10.69'
    ACCESS_TOKEN = token
    client = mqtt.Client()
    # Set access token
    client.username_pw_set(ACCESS_TOKEN)
    # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
    client.connect(host, 1883, 60)

    client.loop_start()

    try:
        print(msg)
        client.publish('v1/devices/Sigfox/telemetry', msg, 1)
        print("sended")
    except KeyboardInterrupt:
        pass

    client.loop_stop()
    client.disconnect()

def a(myresult):
    for x in myresult:
        print('{'+"id_local"+':'+str(x[1])+'}' + " token -> " + str(x[0]) )
        msg={"id_local":int(str(x[1]))}
        sendData(str(msg), str(x[0]))
def b():
    mydbConnector = mysql.connector.connect(
        host="localhost",
        user="adminIOT",
        password="2zKxspRuwdTgiABEo9",
        database="iotPlatform",
    )

    mycursor = mydbConnector.cursor()
    mycursor.execute("SELECT token, internalID FROM iotPlatform.sigfoxCredentials;")
    myresult = mycursor.fetchall()
    a(myresult)
