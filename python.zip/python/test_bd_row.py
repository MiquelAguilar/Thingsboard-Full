import mysql.connector

mydbConnector = mysql.connector.connect(
host="localhost",
user="adminIOT",
password="2zKxspRuwdTgiABEo9",
database="iotPlatform",
)

# device="test_mario"

# myCursor = mydbConnector.cursor()

# myCursor.execute("SELECT * FROM sigfoxCredentials WHERE `name`= '%s';" %(device))

# print(myCursor.fetchall())
# print(len(myCursor.fetchall()))


name = "joer"

myCursor = mydbConnector.cursor()

sql = "SELECT token FROM sigfoxCredentials WHERE `name`= %s;"
val = name
myCursor.execute(sql, (val,))
#test=[]
print("before for")
test = 0
for row in myCursor.fetchall():
    test = row[0]
    print(row)
    print(test)

if test:
    print("existe")
else:
    sql = "INSERT INTO `sigfoxCredentials`(`name`, `token`) VALUES (%s, %s);"
    token = "esto es una prueba"
    val = name, token
    print("antes de la llamada sql")
    myCursor.execute(sql, val)
    mydbConnector.commit()