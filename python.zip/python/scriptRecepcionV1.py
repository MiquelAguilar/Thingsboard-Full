import mysql.connector
import time
import json 
import string
import random
import os

from datetime import datetime, timedelta
from paho.mqtt import client as mqtt_client


broker = 'localhost' #ip or domain of the broker
port = 1883 #comunication port
topic = "#" #topic for sub  of the mqtt suscriptor
client_id = f'server-mqtt-{1}' 

# script credentials
username = 'device'
password = 'device'
client_idClient = 1 # change to set up the id of the client in the database

#max sizes 
# the board cannot get elements and credentials of more than 10 characters CAUTION
m_length_of_things = 10
length_of_string = m_length_of_things 
#data base conection
mydbConnector = mysql.connector.connect(
    host="localhost", 
    user="adminIOT",
    password="2zKxspRuwdTgiABEo9", 
    database="iotPlatform",
)

 #generating the cursor of the database
myCursor = mydbConnector.cursor()



def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    client.username_pw_set(username, password) # user credentials
    client.on_connect = on_connect 
    client.connect(broker, port) #conection created
    return client

# print("Connected to the mqtt server")

def load():
    try:
        myCursor.execute("select max(topicRx) from logicalBrocker;")  
        topicRx = []
        i=0 
        row = myCursor.fetchone():
        topicRx.append(row)

        myCursor.execute("select max(topicTx) from logicalBrocker;")  
        topicTx = []
        i=0 
        row = myCursor.fetchone():
        topicTx.append(row)

        idRx =  gateawyId[0]
        idTx =  gateawyId[0]

        vectorTopicRxSize = int(idRx)
        vectorTopicTxSize = int(idTx)
        
        vectorTopicTx = ["" for o in range(vectorTopicTxSize + 1)] 
        vectorTopicRx = ["" for o in range(vectorTopicRxSize + 1)]
        count = 0
        while count <= vectorTopicRxSize:
            vectorTopicRx[count] = "r"+str(count) # array of the board reception topics
            count += 1

        del count
        count = 0
        while count <= vectorTopicTxSize:        
            vectorTopicTx[count] = "t"+str(count) # array of the board transmision topics
            count += 1
        
        vectorTopic = [vectorTopicTx,vectorTopicRx]
    except:
        print("error in the load of the vectors")
        vectorTopic = [0,0]
    return vectorTopic

def signal_values(signal, sigtec):
    G5_RSRP = 0
    G5_RSRQ = 0
    G5_SINR = 0
    G5_TX_POW = 0
    G4_RSRP = 0
    G4_RSRQ = 0
    G4_SINR = 0
    G4_RSSI = 0
    G4_TX_POW = 0
    G3_RSCP = 0
    G3_ecio = 0

    signalSplit = signal.split(",")

    if sigtec == 0: # 5G SA
        G5_RSRP = signalSplit[0]
        G5_RSRQ = signalSplit[1]
        G5_SINR = signalSplit[2]
        G5_TX_POW = signalSplit[3]
    elif int(sigtec) == 1: # 5G NSA
        G5_RSRP = signalSplit[0]
        G5_RSRQ = signalSplit[1]
        G5_SINR = signalSplit[2]
        G5_TX_POW = signalSplit[3]
        G4_RSRP = signalSplit[4]
        G4_RSRQ = signalSplit[5]
        G4_SINR = signalSplit[6]
        G4_RSSI = signalSplit[7]
        G4_TX_POW = signalSplit[8]
    elif int(sigtec) == 2:     # 4G 
        G4_RSRP = signalSplit[0]
        G4_RSRQ = signalSplit[1]
        G4_SINR = signalSplit[2]
        G4_RSSI = signalSplit[3]
        G4_TX_POW = signalSplit[4]
    elif int(sigtec) == 3: # 3G
        G3_RSCP = signalSplit[0]
        G3_ecio = signalSplit[1]

    return G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio


def  n_pulsos_every_hour(cPulses, messageType,cTimestamp,gateway_id):


    if messageType == "stand":
        cTime = int(str(cTimestamp),16) # hexa to int
        cDateStamp = datetime.fromtimestamp(cTime) #int to datetime
        try:
            myCursor.execute(f"select wakeUpDate,cycleTime, sampleTime from device where sim_idSim = {gateway_id};")
            vResponse = myCursor.fetchone()
            vectorDatabase = []
            for tmp in vResponse:
                vectorDatabase.append(tmp)
            #expected format 2021-08-24 12:10:16.764960
        except:
            vectorDatabase[0] = 0
            vectorDatabase[1] = 1
            vectorDatabase[2] = 2
            print("error in the bbdd conection")

        firstDate = vectorDatabase[0]
        cycleTime = vectorDatabase[1]
        sampleTime = vectorDatabase[2]

        firstDate = firstDate.split(" ") # split half of the string
        yearMonthDay = firstDate[0].split("-") #get the first half and split
        hourMinuteSecond = firstDate[1].split(":") #get the second half and split
        fDate = cDateStamp.replace(year=int(yearMonthDay[0]),month=int(yearMonthDay[1]),day=int(yearMonthDay[2]),hour=int(hourMinuteSecond[0]),minute=int(hourMinuteSecond[1]),second=int(hourMinuteSecond[2]))
        firstDate = int(datetime.timestamp(fDate)) # with the date replaced whe obtain the timestamp in seconds
        newDate = firstDate

        while newDate>firstDate: 
            newDate = firstDate + vectorDatabase[0]
        cPulses = cPulses.split(",")        
        vectorTime = []
        if firstDate == newDate: #if true the array is arranged
            for tmp in cPulses:
                vectorTime.append(int(str(tmp),16))
        else: 
            for tempPulses in cPulses:
                vectorTime.append(int(str(tempPulses),16))
            position = cycleTime/sampleTime
            tmpDate = newDate

            while tmpDate > newDate: 
                tmpDate = tmpDate - sampleTime
                position -= 1 

            nIterations = (cycleTime/sampleTime)-position
            for a in nIterations: 
                vectorTime.insert(0,0)

        # wakeupdate + ta = infinite timestamp wakeUptdateWaiting -> vector & vector inverse

    elif messageType == "ini":
        #############################################to change##############################################################
        vectorTime = [0 for o in range(cycleTime/sampleTime)] # 120 as the max of element(should change to)
############################################################################################################################
    return vectorTime

def loadServer(client: mqtt_client, vectorTopicTx,vectorTopicRx): 
    def on_message(client, userdata, msg):
        
          
        if msg.topic == "a1": # a1 = default expected topic
            messageReceived = msg.payload.decode() # payload should be in binary
            messageReceivedDecoded = messageReceived
            mqttRecieved = messageReceivedDecoded.split(";") 

            if mqttRecieved[0] != None:
                imei = mqttRecieved[0]

            if mqttRecieved[1] != None:
                tim = mqttRecieved[1]
            myCursor.execute("select max(idDevice) from device;")
            gateawyId = [""]
            i=0
            for row in myCursor.fetchall():
                for tmp in row:
                    gateawyId[i]=tmp
                    i+=1
            id =  gateawyId[0]
            id = int(id)+1

            ########################################################################## 
            user = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(length_of_string)) # random string generator, should obtain it from DB
            pas = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(length_of_string)) #random string generator
            ############################################################################################################################
    

            cDate = datetime.now()
            cTime = int(tim)
            # AUTOMATICALLY GENERATE THE SECONDS OF THE ALARM
            cWakeUp = int(datetime.timestamp(cDate.replace(hour=12,minute=30)))  # minute and hour of the alarm       
            if(cTime>cWakeUp):
                cWakeUp = datetime.timestamp(cDate.replace(hour=12,minute=30,day=cDate.day+1))
            t1 = "t"+str(id) 
            t2 = "r"+str(id)
            #check no more than 10 characters if so, change the letter
            mesageToSend = '{"user": {user},"pass":{pass},"timestamp":{timestamp},"topic1":{topic1},"topic2":{topic2}}'
            mesageToSend = {'user': user, 'pass':pas,'timestamp':str(int(cWakeUp-cTime)),'topic1':t1,'topic2':t2}
            result = client.publish(imei, str(mesageToSend)) 

            print(f"sended")
            os.system(f'docker exec RabbitMQ rabbitmqctl add_user {user} {pas}')
            os.system(f'docker exec RabbitMQ rabbitmqctl set_permissions -p / {user} ".*" ".*" ".*"')
            os.system(f'docker exec RabbitMQ rabbitmqctl set_user_tags {user} management')

            #########################################################################################################
            ################### From here the information of the database is created and stored ###########

                            ##### INSERT TO SYSTEM_FEATURES ###################################
            # diameter = 15
            # wakeUpDate = datetime.now() 
            # wakeUpDate = str(wakeUpDate.year) + "-" + str(wakeUpDate.month) + "-" + str(wakeUpDate.day) + " " + str(wakeUpDate.hour) + ":" + str(wakeUpDate.minute) + ":" + str(wakeUpDate.second)     
            # timeLeak = 1
            # volumeLiters = 15
            # diameterFlow = 15

            # myCursor.execute("select max(id) from SYSTEM_FEATURES;")
            # SYSTEM_FEATURES = myCursor.fetchone()
            # caractSystem = SYSTEM_FEATURES[0]
            # caractSystem = caractSystem + 1
            # sql = "INSERT INTO `SYSTEM_FEATURES`(`id`, `diameter`, `wakeUpDate`, `timeLeak`, `volumeLiters`, `diameterFlow`) VALUES (%s, %s, %s, %s, %s, %s);"
            # val = (caractSystem, diameter, wakeUpDate, timeLeak, volumeLiters, diameterFlow)
            # myCursor.execute(sql, val)
            # mydbConnector.commit()
                            ##### INSERT TO GATEWAY_PROPERTIES ###################################
            # default values
            name = "default"
            client = "default"
            device_type = "FIVECOMM LITE 5G"
            location = "default"
            description = "default"
            status = 0
            adquisitionDate = datetime.now()
            credentials_is = 1 # client credential






            sql = "INSERT INTO iotPlatform.sim(Roaming, iccNumber, adquisitionDate, Provider, ipAddress, client_idClient) VALUES (%s, %s, %s, %s, %s, %s, %s);"
            val = (roaming,imei, adquisitionDate,Provider,ipAddress, client_idClient) 
            myCursor.execute(sql, val)
            mydbConnector.commit()

            myCursor.execute("select max(idDevice) from device;")
            deviceId = myCursor.fetchone()
            idDevice = deviceId[0]

            myCursor.execute("select max(idSim) from device;")
            simId = myCursor.fetchone()
            sim_idSim =  simId[0]
            

            sql = "INSERT INTO iotPlatform.device(idDevice, deviceDescription, deviceName, deviceStatus, sim_idSim, client_idClient) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);"
            val = (idDevice,description,client,status,sim_idSim, client_idClient) 
            myCursor.execute(sql, val)
            mydbConnector.commit()


                            ##### INSERT TO MQTT_PROPERTIES###################################
            sql = "INSERT INTO iotPlatform.logicalBrocker(client_idClient, domaintx, domainrx) VALUES (%s, %s, %s);"
            val = (client_idClient,t1,t2)
            myCursor.execute(sql, val)
            mydbConnector.commit()
            ####################################################################
            ####################################################################


            # updating vectorTopicTx y rx
            vectorTopicRx.append(t1)
            vectorTopicTx.append(t2)            
        elif msg.topic in vectorTopicTx:
            #print(msg.topic)
            messageReceived = msg.payload.decode() 
            messageReceivedDecoded = messageReceived
            mqttRecieved = messageReceivedDecoded.split(";") 

            messageType = mqttRecieved[0]
            gateway_id = msg.topic[1:len(msg.topic)] # 


            if str(messageType) == "ini": # expected ini;sigtec;parametro1,parametro2,parametro3;time
                sigtec = mqttRecieved[1]
                sigtecCheck = True

                if int(sigtec) == 0 or int(sigtec) == 1 or int(sigtec) == 2 or int(sigtec) == 3:
                    G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio = signal_values(mqttRecieved[2], sigtec)
                    t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24 = n_pulsos_every_hour(0,messageType,0,gateway_id)
                else:
                    print("error")
                    sigtecCheck = False

                if(sigtecCheck):
                    startupTime = mqttRecieved[3]
                    battery = 100

                                         # NO EJECUTAR none
                    myCursor.execute(f"select command, gateway_id,id FROM REMOTE_CONSOLE WHERE id = (select max(id) from REMOTE_CONSOLE where executed = 0 and gateway_id = {gateway_id});")
                    vectorRemote = [] # duplicamos el tamaño para transmision y recepcion y le sumamos 2 porque es de 0 a Y * 2
                    i=0 
                    tmpRemote = myCursor.fetchall()
                    if len(tmpRemote) != 0:
                        for row in tmpRemote:
                            vectorRemote.append(row)

                        msg3 = '{"id": {id},"command":{command}'
                        if(vectorRemote[0][0] != "none"):
                            msg3 = {'id': vectorRemote[0][1], 'command':vectorRemote[0][0]} 
                            aux = msg.topic
                            # print(msg3)
                            result = client.publish("r"+aux[1:len(aux)], str(msg3)) 

                ######################################################
                    ##### INSERT TO *HISTORY ###################################
                value = "test1"
                name = "prueba BD"
                timestamp = datetime.now()
                GATEWAY_PROPERTIES_id = 1

                #O~O
                myCursor.execute("select max(idContainer) from container;")
                containerId = myCursor.fetchone()
                container_idContainer =  containerId[0]

                cDate = datetime.now()           
                sql =  "INSERT INTO iotPlatform.container (idContainer, name, location, lastUpdate, fullness, `full`, client_idClient, device_idDevice) VALUES(%s, %s, %s,%s, %s, %s, %s, %s, %s);"
                val = (container_idContainer,name,location,cDate,fullness,client_idClient,gateway_id)
                myCursor.execute(sql, val)
                mydbConnector.commit()
                # sql = "INSERT INTO `GATEWAY_HISTORY`(`value`, `name`, `sigtec`, `5G_RSRP`, `5G_RSRQ`, `5G_SINR`, `5G_TX_POW`, `4G_RSRP`, `4G_RSRQ`, `4G_SINR`, `4G_RSSI`, `4G_TX_POW`, `3G_RSCP`,\
                #     `3G_ecio`, `t0`, `t1`, `t2`, `t3`, `t4`, `t5`, `t6`, `t7`, `t8`, `t9`, `t10`, `t11`, `t12`, `t13`, `t14`, `t15`, `t16`, `t17`, `t18`, `t19`, `t20`, `t21`, `t22`,\
                #         `t23`, `t24`, `GATEWAY_PROPERTIES_id`, `battery`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
                # val = (value, name, sigtec, G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio, t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11,
                #         t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, GATEWAY_PROPERTIES_id, battery)
                # myCursor.execute(sql, val)
                # mydbConnector.commit()
                ######################################################
                ######################################################


            elif messageType == "stand": # expected stand;sigtec;parametro1,parametro2,parametro3;timestamp1,timestamp2;payload;battery
                sigtec = mqttRecieved[1]
                sigtecCheck = True
                if int(sigtec) == 0 or int(sigtec) == 1 or int(sigtec) == 2 or int(sigtec) == 3:

                    firstTime = mqttRecieved[4]
                    cDate = datetime.now()
                    tempTime = datetime.timestamp(cDate)
                    cHexTime = hex(int(tempTime))[2:len(hex(int(tempTime)))] 

                    if (int(firstTime[0],16) > int(cHexTime,16)):   #We check that what they have sent us is less than 10 days ago, if it were not, we put it to the relevant date
                        firstTime = str(hex(int(cHexTime[0:3],16)-1)) + firstTime + "0" # if it is less than one turn in the cycle so the period is more than 10 days ago
                        firstTime = firstTime[2:len(firstTime)]
                    else:
                        firstTime = cHexTime[0:3] + firstTime+"0"

                    G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio = signal_values(mqttRecieved[2], sigtec)
                    vectorTimestamps = n_pulsos_every_hour(mqttRecieved[3],messageType,firstTime,gateway_id)
                else:
                    print("error")
                    sigtecCheck = False

                if(mqttRecieved[5]):
                    battery = mqttRecieved[5]

                                         # NO EJECUTAR none
                    myCursor.execute(f"select command, gateway_id,id FROM REMOTE_CONSOLE WHERE id = (select max(id) from REMOTE_CONSOLE where executed = 0 and gateway_id = {gateway_id});")
                    vectorRemote = [] # duplicamos el tamaño para transmision y recepcion y le sumamos 2 porque es de 0 a Y * 2
                    i=0 
                    tmpRemote = myCursor.fetchall()
                    if len(tmpRemote) != 0:
                        for row in tmpRemote:
                            vectorRemote.append(row)

                        msg3 = '{"id": {id},"command":{command}'
                        if(vectorRemote[0][0] != "none"):
                            msg3 = {'id': vectorRemote[0][1], 'command':vectorRemote[0][0]} 
                            aux = msg.topic
                            # print(msg3)
                            result = client.publish("r"+aux[1:len(aux)], str(msg3)) 


                    ######################################################
                    ##### INSERT TO GATEWAY_HISTORY ###################################
                    value = "test1"
                    name = "prueba BD"
                    timestamp = datetime.now()
                    GATEWAY_PROPERTIES_id = 1

                    #O~O                
                    myCursor.execute("select max(idContainer) from container;")
                    containerId = myCursor.fetchone()
                    container_idContainer =  containerId[0]

                    cDate = datetime.now()           
                    sql =  "INSERT INTO iotPlatform.container (idContainer, name, location, lastUpdate, fullness, `full`, client_idClient, device_idDevice) VALUES(%s, %s, %s,%s, %s, %s, %s, %s, %s);"
                    val = (container_idContainer,name,location,cDate,fullness,client_idClient,gateway_id)
                    myCursor.execute(sql, val)
                    mydbConnector.commit()

                    # sql = "INSERT INTO `GATEWAY_HISTORY`(`value`, `name`, `sigtec`, `5G_RSRP`, `5G_RSRQ`, `5G_SINR`, `5G_TX_POW`, `4G_RSRP`, `4G_RSRQ`, `4G_SINR`, `4G_RSSI`, `4G_TX_POW`, `3G_RSCP`,\
                    #     `3G_ecio`, `vTimes`, `GATEWAY_PROPERTIES_id`, `battery`) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
                    # val = (value, name, sigtec, G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio, str(vectorTimestamps), GATEWAY_PROPERTIES_id, battery)
                    # myCursor.execute(sql, val)
                    # mydbConnector.commit()

                    ######################################################
                    ######################################################                    

            elif messageType == "atcom": 
                response = mqttRecieved[1]
                timestamp = datetime.now()

                myCursor.execute("SELECT MAX(id) FROM REMOTE_CONSOLE")
                REMOTE_CONSOLE_id = myCursor.fetchone()
                remoteId = REMOTE_CONSOLE_id[0]
                
                sql = "INSERT INTO `REMOTE_CONSOLE_RESPONSE`(`response`, `timestamp`, `REMOTE_CONSOLE_id`) VALUES(%s, %s, %s)"
                values = response, timestamp, remoteId
                myCursor.execute(sql, values)                

        elif msg.topic in vectorTopicRx:
            print("board red")
            print(msg.payload)
            print(msg.topic)            
        else:
            print("warning!")
            print(msg.payload)
            print(msg.topic)

    client.loadServer(topic)
    client.on_message = on_message


def run():
    #try:
        client = connect_mqtt() # conection to the server
        vectorTopic = load()
        vectorTopicTx = vectorTopic[0]
        vectorTopicRx = vectorTopic[1]
        loadServer(client,vectorTopicTx,vectorTopicRx) #connects to broker, deberiamos cambiar el nombre de la fnc
        client.loop_forever() #loop
    #except:
    #    print("error_error")

if __name__ == '__main__':
    run()
