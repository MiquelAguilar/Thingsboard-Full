import mysql.connector
import time
import json 
import string
import random
import os
import math
import requests
import math
import numpy as np

from requests.structures import CaseInsensitiveDict
from datetime import datetime, timedelta
from calendar import monthrange
from paho.mqtt import client as mqtt_client

# battery level constant
minValue = 0
maxValue = 100
changeSpeed = 0.05
balanceCounter = 0

broker = 'localhost' #ip or domain of the broker
port = 1883 #comunication port
topic = "#" #topic for sub  of the mqtt suscriptor
client_id = f'server-mqtt-{1}' 

# script credentials
username = 'device'
password = 'device'

#max sizes 
# the board cannot get elements and credentials of more than 10 characters CAUTION
m_length_of_things = 10
length_of_string = m_length_of_things 
#data base conection
mydbConnector = mysql.connector.connect(
    host="localhost", 
    user="adminIOT",
    password="2zKxspRuwdTgiABEo9",
    database="iotPlatform",
)

 #generating the cursor of the database
myCursor = mydbConnector.cursor()

def makingLogsDir(directory):
    if not os.path.isdir(directory):
        try:
                os.makedirs(directory)
        except OSError:
                pass


def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)
    try:
        client = mqtt_client.Client(client_id)
        client.username_pw_set(username, password) # user credentials
        client.on_connect = on_connect 
        client.connect(broker, port) #conection created
        print("r")
    except:
            textToWrite = b"Error connecting to the broker\n"
            logFile = open("logs/backendErrors.txt", "ab")
            cDate = datetime.now()           
            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
    
            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            logFile.close()
            print(textToWrite.decode('ASCII'))
    return client

# print("Connected to the mqtt server")

def load():
    try:
        myCursor.execute("select max(idDevice) from device;")
        variables = [""]
        i=0 
        for row in myCursor.fetchall():
            for tmp in row:
                variables[i]=tmp
                i+=1
    except:
            textToWrite = b"Error obtaining the last id of device\n"
            logFile = open("logs/backendErrors.txt", "ab")
            cDate = datetime.now()           
            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
    
            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            logFile.close()
            print(textToWrite.decode('ASCII'))
    try:
        id =  variables[0]
        vectorTopicTxSize = int(id)
        vectorTopicTx = ["" for o in range(vectorTopicTxSize + 1)] 
        vectorTopicRx = ["" for o in range(vectorTopicTxSize + 1)]
        count = 0
        while count <= variables[0]:
            vectorTopicRx[count] = "r"+str(count) # array of the board transmision topics
            vectorTopicTx[count] = "t"+str(count) # array of the board reception topics
            count += 1
        vectorTopic = [vectorTopicTx,vectorTopicRx]
    except:
            textToWrite = b"Error handling topic Vectors\n"
            logFile = open("logs/backendErrors.txt", "ab")
            cDate = datetime.now()           
            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
    
            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            logFile.close()
            print(textToWrite.decode('ASCII'))
    return vectorTopic

def signal_values(signal, sigtec):
    try:
        G5_RSRP = 0
        G5_RSRQ = 0
        G5_RSSI = 0
        G5_SINR = 0
        G5_TX_POW = 0
        G4_RSRP = 0
        G4_RSRQ = 0
        G4_SINR = 0
        G4_RSSI = 0
        G4_TX_POW = 0
        G3_RSCP = 0
        G3_ecio = 0

        tmp = signal.split(",")

        if sigtec == 0: # 5g SA
            G5_RSRP = tmp[0]
            G5_RSRQ = tmp[1]
            G5_RSSI = tmp[2]
            G5_SINR = tmp[3]
            G5_TX_POW = tmp[4]
        elif int(sigtec) == 1: # 5g NSA
            G5_RSRP = tmp[0]
            G5_RSRQ = tmp[1]
            G5_RSSI = tmp[2]
            G5_SINR = tmp[3]
            G5_TX_POW = tmp[4]
            G4_RSRP = tmp[5]
            # G4_RSRQ = tmp[5]
            # G4_SINR = tmp[6]
            # G4_RSSI = tmp[7]
            # G4_TX_POW = tmp[8]    
        elif int(sigtec) == 2:# 4g 
            G4_RSRP = tmp[0]
            G4_RSRQ = tmp[1]
            G4_SINR = tmp[2]
            G4_RSSI = tmp[3]
            G4_TX_POW = tmp[4]
        elif int(sigtec) == 3: # 3g
            G3_RSCP = tmp[0]
            G3_ecio = tmp[1]
    except:
        textToWrite = b"Error handling the signal values\n"
        logFile = open("logs/backendErrors.txt", "ab")
        cDate = datetime.now()           
        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)

        logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
        logFile.close()
        print(textToWrite.decode('ASCII'))
    return G5_RSRP, G5_RSRQ,G5_RSSI, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio

# def envioJson(serialNumber,Ctimestampv,vPulses,connectionData,battery,alarm):
#     try:
#         url = "https://api01-pn5g.go-aigua.com/loadReadings"
#         headers = CaseInsensitiveDict()
#         headers["Accept"] = "application/json"
#         headers["Authorization"] = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL25pZmktcG41Zy5nby1haWd1YS5jb20vIiwiaWF0IjoxNjMxMDg3OTkxLCJleHAiOjI1Nzc3NzI3OTEsImF1ZCI6ImZpdmVjb21tIiwic3ViIjoiIn0.pKj8Si9DCgzSzS5yN7OCeY3s6wjmQh-lvPb5o7zsu28"        #headers["Authorization"] = "hhola"
#         headers["Content-Type"] = "application/json"
#         string = f'"sn": "{serialNumber}","timestamp": "{Ctimestampv}","waterMeterReading": {vPulses[0:24]},"connectionData": {connectionData},"battery": {int(battery)},"alarm": {alarm}'        
        
#         data = "{"+string.replace("'","")+"}"
#         print(data)
#         # coment to dont send JSON to the server
#         # resp = requests.post(url, headers=headers, data=data)

#         #añadido
#         JsonFile = open("logs/backendSends.txt", "ab")
#         cDate = datetime.now()           
#         stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
#         JsonFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+bytes(data,'ascii')+bytes("\n",'ascii'))
#         JsonFile.close()
#         #añadido
#         print("Sended:")
#         # print(resp.status_code)
#     except:
#         textToWrite = b"Error making the JSON\n"
#         logFile = open("logs/backendErrors.txt", "ab")
#         cDate = datetime.now()           
#         stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)

#         logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
#         logFile.close()
#         print(textToWrite.decode('ASCII'))

def batteryConversion(battery_linear):
    try:
        reference_value = 36 
        zero_value = 34
        aux_battery = math.exp(-(reference_value-battery_linear))
        diff_value = math.exp(-(reference_value-zero_value))

        percentile = ((aux_battery-diff_value)/(1-diff_value))*100
        # kohonel algorithm
        global balanceCounter
        global maxValue
        global minValue

        dst = int((maxValue-minValue)/2)
        if percentile >= dst:
            y = maxValue
            balanceCounter = balanceCounter + 1
        else:
            y = minValue
            balanceCounter = balanceCounter - 1
           
        newValue = (1 - changeSpeed) * y + changeSpeed * percentile

        if percentile >= dst:
            maxValue = newValue
        else:
            minValue = newValue

        if balanceCounter > 0:
            result = maxValue
        else:
            result = minValue
            

 



    except:
        textToWrite = b"Error converting the battery\n"
        logFile = open("logs/backendErrors.txt", "ab")
        cDate = datetime.now()           
        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)

        logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
        logFile.close()
        print(textToWrite.decode('ASCII'))
    

    return result


##### not need is procesed on DDBB ###################33

# def  n_pulsos_every_hour(cPulses, typ,cTimestamp,gateway_id):


#     if typ == "stand":
#         cTime = int(str(cTimestamp),16) # hexa to int
#         cDateStamp = datetime.fromtimestamp(cTime) #int to datetime
#         try:
#             myCursor.execute(f"select wakeUpDate,cycleTime, sampleTime from SYSTEM_FEATURES where id = {gateway_id};")
#             vDb = myCursor.fetchone()
#             vectorDatabase = []
#             for tmp in vDb:
#                 vectorDatabase.append(tmp)
#             #expected format 2021-08-24 12:10:16.764960
#         except:
#             textToWrite = b"Error obtaining the values wakeUpDate,cycleTime, sampleTime of SYSTEM_FEATURES"
#             logFile = open("logs/backendErrors.txt", "ab")
#             cDate = datetime.now()           
#             stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
#     
#             logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
#             logFile.close()
#             print(textToWrite.decode('ASCII'))

#         firstDate = vectorDatabase[0]
#         cycleTime = vectorDatabase[1]
#         sampleTime = vectorDatabase[2]

#         firstDate = firstDate.split(" ") # split half of the string
#         yearMonthDay = firstDate[0].split("-") #get the first half and split
#         hourMinuteSecond = firstDate[1].split(":") #get the second half and split
#         fDate = cDateStamp.replace(year=int(yearMonthDay[0]),month=int(yearMonthDay[1]),day=int(yearMonthDay[2]),hour=int(hourMinuteSecond[0]),minute=int(hourMinuteSecond[1]),second=int(hourMinuteSecond[2]))
#         firstDate = int(datetime.timestamp(fDate)) # with the date replaced whe obtain the timestamp in seconds
#         newDate = firstDate

#         while newDate>firstDate: 
#             newDate = firstDate + vectorDatabase[0]
#         cPulses = cPulses.split(",")        
#         vectorTime = []
#         if firstDate == newDate: #if true the array is arranged
#             for tmp in cPulses:
#                 vectorTime.append(int(str(tmp),16))
#             while len(vectorTime) != 121:
#                 vectorTime.append(0)
#         else: 
#             for tempPulses in cPulses:
#                 vectorTime.append(int(str(tempPulses),16))
#             position = cycleTime/sampleTime
#             tmpDate = newDate

#             while tmpDate > newDate: 
#                 tmpDate = tmpDate - sampleTime
#                 position -= 1 

#             nIterations = (cycleTime/sampleTime)-position    
#             for a in nIterations: 
#                 vectorTime.insert(0,0)

#             while len(vectorTime) != 121:
#                 vectorTime.append(0)
#         # wakeupdate + ta = infinite timestamp wakeUptdateWaiting -> vector & vector inverse

#     elif typ == "ini":
#         vectorTime = [0 for o in range(121)] # 120 as the max of element

#     return vectorTime

def subscribe(client: mqtt_client, vectorTopicTx,vectorTopicRx): # deberiamos cambiar el nombre
    def on_message(client, userdata, msg):
        
          
        if msg.topic == "a1":
            try:
                try:
                    messageReceived = msg.payload.decode() #se recibe el mensaje codificado en Hexadecimal
                    messageReceivedDecoded = messageReceived
                    mqttRecieved = messageReceivedDecoded.split(";") 
                except:
                    textToWrite = b"Error decoding the a1 topic message\n"
                    logFile = open("logs/backendErrors.txt", "ab")
                    cDate = datetime.now()           
                    stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            
                    logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                    logFile.close()
                    print(textToWrite.decode('ASCII'))

                 
                try:
                    if mqttRecieved[0] != None and str(mqttRecieved[0]).isnumeric():
                        imei = mqttRecieved[0]
                    if mqttRecieved[1] != None:
                        tim = mqttRecieved[1]
                    print(f"select count(idDevice) from device where imei = {imei};")
                    myCursor.execute(f"select count(idDevice) from device where imei = {imei};")
                    check = []
                    for row in myCursor.fetchall():
                            check.append(row)
            
                    if int(check[0][0]) > 0:
                        # print(f"select id from device where imei = {imei};")
                        myCursor.execute(f"select idDevice from device where imei = {imei};")
                        cId = []
                        for row in myCursor.fetchall():
                            cId.append(row)
                except:
                    textToWrite = b"Error checking the imei\n"
                    logFile = open("logs/backendErrors.txt", "ab")
                    cDate = datetime.now()           
                    stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            
                    logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                    logFile.close()
                    print(textToWrite.decode('ASCII'))    
                if int(check[0][0]) == 0:
                        
                        ## cambiar a id + 1, luego insert y ya   
                        try:
                            myCursor.execute("select max(idDevice) from device;")
                            variables = [""]
                            i=0
                            for row in myCursor.fetchall():
                                for tmp in row:
                                    variables[i]=tmp
                                    i+=1
                        except:
                            textToWrite = b"Error obtaining the las id from device\n"
                            logFile = open("logs/backendErrors.txt", "ab")
                            cDate = datetime.now()           
                            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                            logFile.close()
                            print(textToWrite.decode('ASCII'))        
                        id =  variables[0]
                        id = int(id)+1

                        ########################################################################## se puede optimizar generando por defecto un usuario y contraseña al arranque y si se usa se regenera
                        user = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(length_of_string)) # random string generator, should obtain it from DB
                        pas = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(length_of_string)) #random string generator
                        ############################################################################################################################
                

                        cDate = datetime.now()
                        cTime = int(tim)
                        # GENERAR DE FORMA AUTOMATICA LOS SEGUNDOS DE LA ALARMA
                        cWakeUp = int(datetime.timestamp(cDate.replace(hour=12,minute=30)))  # minuto y hora de alarma       
                        if(cTime>cWakeUp):
                            if cDate.day == monthrange(cDate.year, cDate.month)[1]:
                                cWakeUp = datetime.timestamp(cDate.replace(month=cDate.month+1,hour=12,minute=30,day=1))
                            else:
                                cWakeUp = datetime.timestamp(cDate.replace(hour=12,minute=30,day=cDate.day+1))
                        # tiempo_envio = tiempo_inicial_placa - tiempo_codigo
                        t1 = "t"+str(id) 
                        t2 = "r"+str(id)
                        #comprobar no mas de 10 caracteres si fuera asi, cambia la letra
                        msg2 = '{"user": {user},"pass":{pass},"timestamp":{timestamp},"topic1":{topic1},"topic2":{topic2}}'
                        # msg2 = {'user': user, 'pass':pas,'timestamp':str(int(cWakeUp-cTime)),'topic1':t1,'topic2':t2}
                        msg2 = {'user': user, 'pass':pas,'timestamp':'120','topic1':t1,'topic2':t2}
                        result = client.publish(imei, str(msg2)) 

                        print(f"sended")
                        os.system(f'docker exec -it mqtt mosquitto_passwd -b mosquitto/passwordfile {user} {pas}')
                        

                        #########################################################################################################
                        ################### From here the information of the database is created and stored ###########

                        ##### INSERT TO SYSTEM_FEATURES ###################################
                        diametro = 15
                        wakeUpDate = datetime.now() 
                        wakeUpDate = str(wakeUpDate.year) + "-" + str(wakeUpDate.month) + "-" + str(wakeUpDate.day) + " " + str(wakeUpDate.hour) + ":" + str(wakeUpDate.minute) + ":" + str(wakeUpDate.second)     
                        tFuga = 1
                        volumenLitros = 15
                        caudalDiametro = 15
                        
                        #try:
                        #     myCursor.execute("select max(id) from SYSTEM_FEATURES;")
                        #     CARACTERISTICAS_SISTEMA_id = myCursor.fetchone()
                        #     caractSystem = CARACTERISTICAS_SISTEMA_id[0]
                        #     caractSystem = caractSystem + 1
                        #     sql = "INSERT INTO `SYSTEM_FEATURES`(`id`, `diameter`, `wakeUpDate`, `timeLeak`, `volumeLiters`, `diameterFlow`) VALUES (%s, %s, %s, %s, %s, %s);"
                        #     val = (caractSystem, diametro, wakeUpDate, tFuga, volumenLitros, caudalDiametro)
                        #     myCursor.execute(sql, val)
                        #     mydbConnector.commit()
                        # except:
                        #     textToWrite = b"Error inserting values on SYSTEM_FEATURES\n"
                        #     logFile = open("logs/backendErrors.txt", "ab")
                        #     cDate = datetime.now()           
                        #     stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                        #     logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                        #     logFile.close()
                        #     print(textToWrite.decode('ASCII')) 

                        ##### INSERT TO device ###################################
                        # default values
                        name = t1
                        client = t1
                        device_type = "FIVECOMM_LITE_5G"
                        location = "default"
                        description = "default"
                        timestamp = datetime.now()
                        #print(timestamp)
                        CREDENCIALES_id = 1 # increase if other client is using the code
                        try:
                            print("EMPEZAMOS")
                            
                            sql = "INSERT INTO `device`(`imei`, `deviceName`, `client_idClient`, `deviceStatus`, `deviceDescription`,`sampleTime`) VALUES (%s, \"%s\", %s, \"%s\", %s, %s);"
                            id_Client = 1 # Hay que cambiar en un futuro -!!!!!!!!!!!!!!!1
                            val = (imei, name, id_Client, device_type, description, str(7200)) 
                        
                            print("INSERT INTO `device`(`imei`, `deviceName`, `client_idClient`, `deviceStatus`, `deviceDescription`,`sampleTime`) VALUES (%s, \"%s\", %s, \"%s\", %s, %s);"%val)
                            myCursor.execute(sql, val)
                            mydbConnector.commit()

                            # sql = "INSERT INTO `devicePosition`(`actualPosition`,`lastPosition`,`idDevice`) VALUES (%s,%s,%s)"
                            # val = (location,location,gateway_id)
                            # print(val)
                            # myCursor.execute(sql, val)
                            # mydbConnector.commit()


                        # !!!!!!!!location no existe en la BD, se ha utilizado sampleTime para el timestamp y AUTHORIZATION_id y SYSTEM_FEATURES_id NO están tampoco!!!!!!!!!!!!!!!!!!!!
                        ##### INSERT TO MQTT_PROPERTIES###################################
                            print(val)
                            myCursor.execute("select max(idDevice) from device;")
                            device_id = myCursor.fetchone()
                            idGateway = device_id[0]
                            print(val)
                            sql = "INSERT INTO `logicalBroker`(`domaintx`, `domainrx`,`fk_idDevice`) VALUES (%s, %s, %s);"
                            val = (t1, t2, idGateway)
                            print(val)
                            myCursor.execute(sql, val)
                            print("execute")
                            mydbConnector.commit()
                        except:
                            textToWrite = b"Error inserting values on device and MQTT_PROPERTIES\n"
                            logFile = open("logs/backendErrors.txt", "ab")
                            cDate = datetime.now()           
                            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                            logFile.close()
                            print(textToWrite.decode('ASCII')) 
                        ####################################################################
                        ####################################################################


                        # actualizando vectorTopicTx y rx
                        vectorTopicTx.append(t1)
                        vectorTopicRx.append(t2)
                else:
                        t1 = "t"+str(cId[0][0]) 
                        t2 = "r"+str(cId[0][0])
                        cTime = int(tim)
                        cDate = datetime.now()
                        cWakeUp = int(datetime.timestamp(cDate.replace(hour=12,minute=30)))  # minuto y hora de alarma     
                        if(cTime>cWakeUp):
                            if cDate.day == monthrange(cDate.year, cDate.month)[1]:
                                cWakeUp = datetime.timestamp(cDate.replace(month=cDate.month+1,hour=12,minute=30,day=1))
                            else:
                                cWakeUp = datetime.timestamp(cDate.replace(hour=12,minute=30,day=cDate.day+1))   
                        try:
                            myCursor.execute(f"select mqttuser, mqttpassword from device where device_id ={cId[0][0]} ;")
                            CARACTERISTICAS_SISTEMA_id = myCursor.fetchone()
                            user = CARACTERISTICAS_SISTEMA_id[0]
                            pas = CARACTERISTICAS_SISTEMA_id[1]
                        except:
                            textToWrite = b"Error obtaining user and pass\n"
                            logFile = open("logs/backendErrors.txt", "ab")
                            cDate = datetime.now()           
                            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                            logFile.close()
                            print(textToWrite.decode('ASCII')) 

                        #comprobar no mas de 10 caracteres si fuera asi, cambia la letra
                        msg2 = '{"user": {user},"pass":{pass},"timestamp":{timestamp},"topic1":{topic1},"topic2":{topic2}}'
                        # msg2 = {'user': user, 'pass':pas,'timestamp':str(int(cWakeUp-cTime)),'topic1':t1,'topic2':t2}
                        msg2 = {'user': user, 'pass':pas,'timestamp':'120','topic1':t1,'topic2':t2}

                        print(msg2)
                        result = client.publish(imei, str(msg2)) 

            except:
                textToWrite = b"Error with a1\n"
                logFile = open("logs/backendErrors.txt", "ab")
                cDate = datetime.now()           
                stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                logFile.close()
                print(textToWrite.decode('ASCII'))            
        elif msg.topic in vectorTopicTx:
            try:
                # print(msg.payload)
                # print(msg.topic)
                messageReceived = msg.payload.decode() #se recibe el mensaje codificado en Hexadecimal
                messageReceivedDecoded = messageReceived
                mqttRecieved = messageReceivedDecoded.split(";") #Para mis pruebas
                # iccNumber; type; error; gateway_id; sigtec; ; payload; battery

                typ = mqttRecieved[0]
                gateway_id = msg.topic[1:len(msg.topic)] # 
            except:
                textToWrite = b"Error decoding the a1 topic message\n"
                logFile = open("logs/backendErrors.txt", "ab")
                cDate = datetime.now()           
                stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
        
                logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                logFile.close()
                print(textToWrite.decode('ASCII'))


            if str(typ) == "ini": # espera ini;sigtec;parametro1,parametro2,parametro3;time
                try:
                    try:
                        sigtec = mqttRecieved[1]
                        comprobacionSigtec = True
                        initValue = mqttRecieved[2]
                        diameter = mqttRecieved[4] #?
                        timeLeak = 24
                        volumenLitros = 15
                        caudalDiametro = 100
                        cDate = datetime.now()
                    except:
                        textToWrite = b"Error in handling ini payload\n"
                        logFile = open("logs/backendErrors.txt", "ab")
                        cDate = datetime.now()           
                        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                
                        logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                        logFile.close()
                        print(textToWrite.decode('ASCII')) 
                     
                    if int(sigtec) == 0 or int(sigtec) == 1 or int(sigtec) == 2 or int(sigtec) == 3:
                        G5_RSRP, G5_RSRQ,G5_RSSI, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio = signal_values(mqttRecieved[2], sigtec)
                        # vectorTimestamps = n_pulsos_every_hour(0,typ,0,gateway_id)
                    else:
                        comprobacionSigtec = False
                    if(comprobacionSigtec):
                        startupTime = mqttRecieved[3]
                        battery = 100
                        # NO EJECUTAR none
            
                            
                            
                    ######################################################
                        ##### INSERT TO GATEWAY_HISTORY ###################################
                    value = "test1"
                    name = "prueba BD"
                    timestamp = datetime.now()
                    device_id = 1

                    
                    # try:
                    #     sql = "INSERT INTO n8htgo8_fivecomm.GATEWAY_HISTORY (battery, device_id, value, name, sigtec, `5G_RSRP`, `5G_RSRQ`, `5G_SINR`, `5G_TX_POW`, `4G_RSRP`, `4G_RSRQ`, `4G_SINR`, `4G_RSSI`, `4G_TX_POW`, `3G_RSCP`, `3G_ecio`, t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33, t34, t35, t36, t37, t38, t39, t40, t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51, t52, t53, t54, t55, t56, t57, t58, t59, t60, t61, t62, t63, t64, t65, t66, t67, t68, t69, t70, t71, t72, t73, t74, t75, t76, t77, t78, t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97, t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112, t113, t114, t115, t116, t117, t118, t119, t120) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
                    #     val = (battery,device_id,value, name, sigtec, G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio, vectorTimestamps[0],vectorTimestamps[1], vectorTimestamps[2], vectorTimestamps[3], vectorTimestamps[4], vectorTimestamps[5], vectorTimestamps[6], vectorTimestamps[7], vectorTimestamps[8], vectorTimestamps[9], vectorTimestamps[10], vectorTimestamps[11], vectorTimestamps[12], vectorTimestamps[13], vectorTimestamps[14], vectorTimestamps[15], vectorTimestamps[16], vectorTimestamps[17], vectorTimestamps[18], vectorTimestamps[19], vectorTimestamps[20], vectorTimestamps[21], vectorTimestamps[22], vectorTimestamps[23], vectorTimestamps[24], vectorTimestamps[25], vectorTimestamps[26], vectorTimestamps[27], vectorTimestamps[28], vectorTimestamps[29], vectorTimestamps[30], vectorTimestamps[31], vectorTimestamps[32], vectorTimestamps[33], vectorTimestamps[34], vectorTimestamps[35], vectorTimestamps[36], vectorTimestamps[37], vectorTimestamps[38], vectorTimestamps[39], vectorTimestamps[40], vectorTimestamps[41], vectorTimestamps[42], vectorTimestamps[43], vectorTimestamps[44], vectorTimestamps[45], vectorTimestamps[46], vectorTimestamps[47], vectorTimestamps[48], vectorTimestamps[49], vectorTimestamps[50], vectorTimestamps[51], vectorTimestamps[52], vectorTimestamps[53], vectorTimestamps[54], vectorTimestamps[55], vectorTimestamps[56], vectorTimestamps[57], vectorTimestamps[58], vectorTimestamps[59], vectorTimestamps[60], vectorTimestamps[61], vectorTimestamps[62], vectorTimestamps[63], vectorTimestamps[64], vectorTimestamps[65], vectorTimestamps[66], vectorTimestamps[67], vectorTimestamps[68], vectorTimestamps[69], vectorTimestamps[70], vectorTimestamps[71], vectorTimestamps[72], vectorTimestamps[73], vectorTimestamps[74], vectorTimestamps[75], vectorTimestamps[76], vectorTimestamps[77], vectorTimestamps[78], vectorTimestamps[79], vectorTimestamps[80], vectorTimestamps[81], vectorTimestamps[82], vectorTimestamps[83], vectorTimestamps[84], vectorTimestamps[85], vectorTimestamps[86], vectorTimestamps[87], vectorTimestamps[88], vectorTimestamps[89], vectorTimestamps[90], vectorTimestamps[91], vectorTimestamps[92], vectorTimestamps[93], vectorTimestamps[94], vectorTimestamps[95], vectorTimestamps[96], vectorTimestamps[97], vectorTimestamps[98], vectorTimestamps[99], vectorTimestamps[100], vectorTimestamps[101], vectorTimestamps[102], vectorTimestamps[103], vectorTimestamps[104], vectorTimestamps[105], vectorTimestamps[106], vectorTimestamps[107], vectorTimestamps[108], vectorTimestamps[109], vectorTimestamps[110], vectorTimestamps[111], vectorTimestamps[112], vectorTimestamps[113], vectorTimestamps[114], vectorTimestamps[115], vectorTimestamps[116], vectorTimestamps[117], vectorTimestamps[118], vectorTimestamps[119], vectorTimestamps[120])
                    #     myCursor.execute(sql, val)
                    #     mydbConnector.commit()
                    # except:
                    #     textToWrite = b"Error inserting values on GATEWAY_HISTORY "
                    #     logFile = open("logs/backendErrors.txt", "ab")
                    #     cDate = datetime.now()           
                    # stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    # textToWrite = b"Principal thread error\n"
                    # logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                    #     logFile.close()
                    #     print(textToWrite.decode('ASCII')) 
                    ######################################################
                    ######################################################
                except:
                    textToWrite = b"Error in the ini payload\n"
                    logFile = open("logs/backendErrors.txt", "ab")
                    cDate = datetime.now()           
                    stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            
                    logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                    logFile.close()
                    print(textToWrite.decode('ASCII')) 

            elif typ == "stand": # espera stand;sigtec;parametro1,parametro2,parametro3;timestamp1,timestamp2;payload;battery
                try:
                    accumulated = mqttRecieved[5]
                    CELL_ID = mqttRecieved[6]
                    sigtec = mqttRecieved[1]
                    comprobacionSigtec = True
                    if int(sigtec) == 0 or int(sigtec) == 1 or int(sigtec) == 2 or int(sigtec) == 3:
                        firstTime = mqttRecieved[4]

                        cTime = datetime.fromtimestamp(int(firstTime))

                        if cTime.month < 10:
                            monthPrevious = "0"+str(cTime.month)
                        else:
                            monthPrevious = str(cTime.month)
                
                        if cTime.day < 10:
                            dayPrevious = "0"+str(cTime.day)
                        else:
                            dayPrevious = str(cTime.day)

                        if cTime.hour < 10:
                            hourPrevious = "0"+str(cTime.hour)
                        else:
                            hourPrevious = str(cTime.hour)
                        
                        if cTime.minute < 10:
                            minutePrevious = "0"+str(cTime.minute)
                        else:
                            minutePrevious = str(cTime.minute)

                        if cTime.second < 10:
                            secondPrevious = "0"+str(cTime.second)
                        else:
                            secondPrevious = str(cTime.second)    

                        # stringDate = str(cTime.year) + "-" + monthPrevious + "-" + dayPrevious + " " + hourPrevious + ":" + minutePrevious + ":" + secondPrevious
                        stringDate = str(cTime.year) + "-" + monthPrevious + "-" + dayPrevious + " " + hourPrevious + ":00:00"

                        ### añadido para json ##
                        Ctimestampv = stringDate
                        ########################
                        G5_RSRP, G5_RSRQ,G5_RSSI, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio = signal_values(mqttRecieved[2], sigtec)
                    # vectorTimestamps = n_pulsos_every_hour(mqttRecieved[4],typ,firstTime,gateway_id)
                        vectorTimestamps = mqttRecieved[3].split(",")
                    else:
                        print("error")
                        comprobacionSigtec = False
                    if(mqttRecieved[7]):
                        tmpBattery = mqttRecieved[7]
                        battery = int(tmpBattery)/100.0
                        battery = math.ceil(battery)/10.0
                        battery = batteryConversion(battery)

                    ######################################################
                    ##### INSERT TO GATEWAY_HISTORY ###################################
                    value = "test1"
                    name = "pruebaBD"
                    if firstTime != 0:
                        timestamp = Ctimestampv
                    else:
                        cTime = datetime.now()
                        timestamp = str(cTime.year) + "-" + monthPrevious + "-" + dayPrevious + " " + hourPrevious + ":00:00"

                    serialNumber = msg.topic.replace("t", "")
                    serialNumber = int(serialNumber)
                    device_id = serialNumber
                    try:
                        sql = "INSERT INTO n8htgo8_fivecomm.GATEWAY_HISTORY (timestamp,accumulated,CELL_ID,battery, device_id, value, name, sigtec, `5G_RSRP`, `5G_RSRQ`,`G5_RSSI` ,`5G_SINR`, `5G_TX_POW`, `4G_RSRP`, `4G_RSRQ`, `4G_SINR`, `4G_RSSI`, `4G_TX_POW`, `3G_RSCP`, `3G_ecio`, t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33, t34, t35, t36, t37, t38, t39, t40, t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51, t52, t53, t54, t55, t56, t57, t58, t59, t60, t61, t62, t63, t64, t65, t66, t67, t68, t69, t70, t71, t72, t73, t74, t75, t76, t77, t78, t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97, t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112, t113, t114, t115, t116, t117, t118, t119, t120) VALUES(%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
                        
                        # to check
                       
                       
                        while len(vectorTimestamps) != 121:
                            vectorTimestamps.append(0)
                        # print(vectorTimestamps)                                                                              G5_RSRP, G5_RSRQ,G5_RSSI, G5_SINR,         
                        # val = (int(accumulated,16),CELL_ID,int(battery),device_id,str(value), str(name), sigtec, G5_RSRP, G5_RSRQ, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio, int(vectorTimestamps[0],16),int(vectorTimestamps[1],16), int(vectorTimestamps[2],16), int(vectorTimestamps[3],16), int(vectorTimestamps[4],16), int(vectorTimestamps[5],16), int(vectorTimestamps[6],16), int(vectorTimestamps[7],16), int(vectorTimestamps[8],16), int(vectorTimestamps[9],16), int(vectorTimestamps[10],16), int(vectorTimestamps[11],16), int(vectorTimestamps[12],16), int(vectorTimestamps[13],16), int(vectorTimestamps[14],16), int(vectorTimestamps[15],16), int(vectorTimestamps[16],16), int(vectorTimestamps[17],16), int(vectorTimestamps[18],16), int(vectorTimestamps[19],16), int(vectorTimestamps[20],16), int(vectorTimestamps[21],16), int(vectorTimestamps[22],16), int(vectorTimestamps[23],16), int(vectorTimestamps[24],16), int(vectorTimestamps[25],16), int(vectorTimestamps[26],16), int(vectorTimestamps[27],16), int(vectorTimestamps[28],16), int(vectorTimestamps[29],16), int(vectorTimestamps[30],16), int(vectorTimestamps[31],16), int(vectorTimestamps[32],16), int(vectorTimestamps[33],16), int(vectorTimestamps[34],16), int(vectorTimestamps[35],16), int(vectorTimestamps[36],16), int(vectorTimestamps[37],16), int(vectorTimestamps[38],16), int(vectorTimestamps[39],16), int(vectorTimestamps[40],16), int(vectorTimestamps[41],16), int(vectorTimestamps[42],16), int(vectorTimestamps[43],16), int(vectorTimestamps[44],16), int(vectorTimestamps[45],16), int(vectorTimestamps[46],16), int(vectorTimestamps[47],16), int(vectorTimestamps[48],16), int(vectorTimestamps[49],16), int(vectorTimestamps[50],16), int(vectorTimestamps[51],16), int(vectorTimestamps[52],16), int(vectorTimestamps[53],16), int(vectorTimestamps[54],16), int(vectorTimestamps[55],16), int(vectorTimestamps[56],16), int(vectorTimestamps[57],16), int(vectorTimestamps[58],16), int(vectorTimestamps[59],16), int(vectorTimestamps[60],16), int(vectorTimestamps[61],16), int(vectorTimestamps[62],16), int(vectorTimestamps[63],16), int(vectorTimestamps[64],16), int(vectorTimestamps[65],16), int(vectorTimestamps[66],16), int(vectorTimestamps[67],16), int(vectorTimestamps[68],16), int(vectorTimestamps[69],16), int(vectorTimestamps[70],16), int(vectorTimestamps[71],16), int(vectorTimestamps[72],16), int(vectorTimestamps[73],16), int(vectorTimestamps[74],16), int(vectorTimestamps[75],16), int(vectorTimestamps[76],16), int(vectorTimestamps[77],16), int(vectorTimestamps[78],16), int(vectorTimestamps[79],16), int(vectorTimestamps[80],16), int(vectorTimestamps[81],16), int(vectorTimestamps[82],16), int(vectorTimestamps[83],16), int(vectorTimestamps[84],16), int(vectorTimestamps[85],16), int(vectorTimestamps[86],16), int(vectorTimestamps[87],16), int(vectorTimestamps[88],16), int(vectorTimestamps[89],16), int(vectorTimestamps[90],16), int(vectorTimestamps[91],16), int(vectorTimestamps[92],16), int(vectorTimestamps[93],16), int(vectorTimestamps[94],16), int(vectorTimestamps[95],16), int(vectorTimestamps[96],16), int(vectorTimestamps[97],16), int(vectorTimestamps[98],16), int(vectorTimestamps[99],16), int(vectorTimestamps[100],16), int(vectorTimestamps[101],16), int(vectorTimestamps[102],16), int(vectorTimestamps[103],16), int(vectorTimestamps[104],16), int(vectorTimestamps[105],16), int(vectorTimestamps[106],16), int(vectorTimestamps[107],16), int(vectorTimestamps[108],16), int(vectorTimestamps[109],16), int(vectorTimestamps[110],16), int(vectorTimestamps[111],16), int(vectorTimestamps[112],16), int(vectorTimestamps[113],16), int(vectorTimestamps[114],16), int(vectorTimestamps[115],16), int(vectorTimestamps[116],16), int(vectorTimestamps[117],16), int(vectorTimestamps[118],16), int(vectorTimestamps[119],16), int(vectorTimestamps[120],16))
                        
                        val = (timestamp,accumulated,CELL_ID,int(battery),device_id,str(value), str(name), sigtec, G5_RSRP, G5_RSRQ,G5_RSSI, G5_SINR, G5_TX_POW, G4_RSRP, G4_RSRQ, G4_SINR, G4_RSSI, G4_TX_POW, G3_RSCP, G3_ecio, vectorTimestamps[0],vectorTimestamps[1], vectorTimestamps[2], vectorTimestamps[3], vectorTimestamps[4], vectorTimestamps[5], vectorTimestamps[6], vectorTimestamps[7], vectorTimestamps[8], vectorTimestamps[9], vectorTimestamps[10], vectorTimestamps[11], vectorTimestamps[12], vectorTimestamps[13], vectorTimestamps[14], vectorTimestamps[15], vectorTimestamps[16], vectorTimestamps[17], vectorTimestamps[18], vectorTimestamps[19], vectorTimestamps[20], vectorTimestamps[21], vectorTimestamps[22], vectorTimestamps[23], vectorTimestamps[24], vectorTimestamps[25], vectorTimestamps[26], vectorTimestamps[27], vectorTimestamps[28], vectorTimestamps[29], vectorTimestamps[30], vectorTimestamps[31], vectorTimestamps[32], vectorTimestamps[33], vectorTimestamps[34], vectorTimestamps[35], vectorTimestamps[36], vectorTimestamps[37], vectorTimestamps[38], vectorTimestamps[39], vectorTimestamps[40], vectorTimestamps[41], vectorTimestamps[42], vectorTimestamps[43], vectorTimestamps[44], vectorTimestamps[45], vectorTimestamps[46], vectorTimestamps[47], vectorTimestamps[48], vectorTimestamps[49], vectorTimestamps[50], vectorTimestamps[51], vectorTimestamps[52], vectorTimestamps[53], vectorTimestamps[54], vectorTimestamps[55], vectorTimestamps[56], vectorTimestamps[57], vectorTimestamps[58], vectorTimestamps[59], vectorTimestamps[60], vectorTimestamps[61], vectorTimestamps[62], vectorTimestamps[63], vectorTimestamps[64], vectorTimestamps[65], vectorTimestamps[66], vectorTimestamps[67], vectorTimestamps[68], vectorTimestamps[69], vectorTimestamps[70], vectorTimestamps[71], vectorTimestamps[72], vectorTimestamps[73], vectorTimestamps[74], vectorTimestamps[75], vectorTimestamps[76], vectorTimestamps[77], vectorTimestamps[78], vectorTimestamps[79], vectorTimestamps[80], vectorTimestamps[81], vectorTimestamps[82], vectorTimestamps[83], vectorTimestamps[84], vectorTimestamps[85], vectorTimestamps[86], vectorTimestamps[87], vectorTimestamps[88], vectorTimestamps[89], vectorTimestamps[90], vectorTimestamps[91], vectorTimestamps[92], vectorTimestamps[93], vectorTimestamps[94], vectorTimestamps[95], vectorTimestamps[96], vectorTimestamps[97], vectorTimestamps[98], vectorTimestamps[99], vectorTimestamps[100], vectorTimestamps[101], vectorTimestamps[102], vectorTimestamps[103], vectorTimestamps[104], vectorTimestamps[105], vectorTimestamps[106], vectorTimestamps[107], vectorTimestamps[108], vectorTimestamps[109], vectorTimestamps[110], vectorTimestamps[111], vectorTimestamps[112], vectorTimestamps[113], vectorTimestamps[114], vectorTimestamps[115], vectorTimestamps[116], vectorTimestamps[117], vectorTimestamps[118], vectorTimestamps[119], vectorTimestamps[120])
                        # print("INSERT INTO n8htgo8_fivecomm.GATEWAY_HISTORY (timestamp,accumulated,CELL_ID,battery, device_id, value, name, sigtec, `5G_RSRP`, `5G_RSRQ`,`G5_RSSI` ,`5G_SINR`, `5G_TX_POW`, `4G_RSRP`, `4G_RSRQ`, `4G_SINR`, `4G_RSSI`, `4G_TX_POW`, `3G_RSCP`, `3G_ecio`, t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25, t26, t27, t28, t29, t30, t31, t32, t33, t34, t35, t36, t37, t38, t39, t40, t41, t42, t43, t44, t45, t46, t47, t48, t49, t50, t51, t52, t53, t54, t55, t56, t57, t58, t59, t60, t61, t62, t63, t64, t65, t66, t67, t68, t69, t70, t71, t72, t73, t74, t75, t76, t77, t78, t79, t80, t81, t82, t83, t84, t85, t86, t87, t88, t89, t90, t91, t92, t93, t94, t95, t96, t97, t98, t99, t100, t101, t102, t103, t104, t105, t106, t107, t108, t109, t110, t111, t112, t113, t114, t115, t116, t117, t118, t119, t120) VALUES(%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"%val)
                        myCursor.execute(sql, val)
                        mydbConnector.commit()
                        ######################################################
                        ######################################################
                        ### check normal alarms (no pulses a month and too much flow for the diameter)
                        cDate = datetime.now()
                        tempTime = datetime.timestamp(cDate)
                        cHexTime = hex(int(tempTime))[2:len(hex(int(tempTime)))] #tiempo actual en hexadecimal
                        myCursor.execute(f"select diameterFlow from SYSTEM_FEATURES where id=(select SYSTEM_FEATURES_id from device where id = {gateway_id});")
                        fuga = True #leak check
                        tFuga = myCursor.fetchall()# Obtain the leak time from the database based on the gateway id
                        for row in tFuga:
                            tmp = row
                        tFuga = tmp[0]
                        # print(f"select ((volumeLiters)/(diameterFlow))*100 from SYSTEM_FEATURES where id = (select SYSTEM_FEATURES_id from device where id = {gateway_id});")
                        myCursor.execute(f"select ((volumeLiters)/(diameterFlow))*100 from SYSTEM_FEATURES where id = (select SYSTEM_FEATURES_id from device where id = {gateway_id});")
                        cal = myCursor.fetchall()
                        for row in cal:
                            # print(row)
                            tmp = row
                        nPulsos = tmp

                    except:
                        textToWrite = b"Error updating gateway history\n"
                        logFile = open("logs/backendErrors.txt", "ab")
                        cDate = datetime.now()           
                        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                
                        logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                        logFile.close()
                        print(textToWrite.decode('ASCII')) 
                    
                    fuga = True
                    subdimension = False
                    i = 0
                    lenVector = len(vectorTimestamps)
                    # print("como siempre")
                    while(i <= lenVector):
                        if int(vectorTimestamps[i]) == 0:
                            fuga = False
                            i = len(vectorTimestamps)+2
                        else:
                            if int(vectorTimestamps[i]) >= nPulsos[0]:
                                subdimension = True
                            i = i + 1
                    # print("falla esto")
        
                    cDate = datetime.now()


                    stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    del tmp
                    tmp = []
                    alarmName = ""
                    if fuga == True:
                        try:
                            myCursor.execute(f"select name from ALARM where id = 1;")
                            cal = myCursor.fetchall()
                            i = 0   
                            for row in cal:
                                tmp.append(row)
                                i = i+1
                            alarmName = tmp[0][0]
                            
                            myCursor.execute(f"select SYSTEM_FEATURES_id,timeLeak from device JOIN SYSTEM_FEATURES on SYSTEM_FEATURES.id=device.SYSTEM_FEATURES_id where device.id = {gateway_id};")
                            cal = myCursor.fetchall()
                            i = 0
                            tmp = []
                            for row in cal:
                                tmp.append(row)
                                i = i+1
                            idCaracteristicas = tmp[0][0]
                            tFuga = tmp[0][1]

                            myCursor.execute(f"select id from ALARM where SYSTEM_FEATURES_id= {idCaracteristicas};")
                            aId = myCursor.fetchall()
                            alarmId = aId[0][0]

                            sql = "INSERT INTO `ALARM_HISTORY`(`name`, `date`,`ALARM_id`,`timeLeak`) VALUES(%s, %s, %s, %s)"
                            values = alarmName, stringDate,alarmId,tFuga
                            myCursor.execute(sql, values)

                        except:
                            textToWrite = b"Error inserting the subdimension alarm\n"
                            logFile = open("logs/backendErrors.txt", "ab")
                            cDate = datetime.now()           
                            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                            logFile.close()
                            print(textToWrite.decode('ASCII'))  
                    elif subdimension == True:
                        try:
                            myCursor.execute(f"select name from ALARM where id = 2;")
                            cal = myCursor.fetchall()
                            i = 0   
                            for row in cal:
                                tmp.append(row)
                                i = i+1
                            alarmName = tmp[0][0]

                            myCursor.execute(f"select SYSTEM_FEATURES_id,volumeLiters from device JOIN SYSTEM_FEATURES on SYSTEM_FEATURES.id=device.SYSTEM_FEATURES_id where device.id = {gateway_id};")
                            cal = myCursor.fetchall()
                            i = 0
                            tmp = []
                            for row in cal:
                                tmp.append(row) 
                                i = i+1
                            idCaracteristicas = tmp[0][0]
                            volumenLitros = tmp[0][1]
                            myCursor.execute(f"select id from ALARM where SYSTEM_FEATURES_id= {idCaracteristicas};")
                            aId = myCursor.fetchall()
                            if len(aId)!=0:
                                alarmId = aId[0][0]

                                sql = "INSERT INTO ALARM_HISTORY(name, date,ALARM_id,volumeLiters) VALUES(%s, %s,%s, %s);"
                                values = alarmName, stringDate,alarmId,volumenLitros
                                myCursor.execute(sql, values)
                                mydbConnector.commit()
                        except:
                            textToWrite = b"Error inserting the subdimension alarm\n"
                            logFile = open("logs/backendErrors.txt", "ab")
                            cDate = datetime.now()           
                            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                            logFile.close()
                            print(textToWrite.decode('ASCII'))  

                    cDate = datetime.now()           
                    cDate = cDate.replace(month=cDate.month-1) # minute and alarm time
                    if cDate.day == 31:
                        cDate = cDate.replace(day = cDate.day-1)
                    try:    
                        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                        myCursor.execute(f"SELECT count(*) FROM GATEWAY_HISTORY where t0 = 0 and t1 = 0 and t2 = 0 and t3 = 0 and t4 = 0 and t5 = 0 and t6 = 0 and t7 = 0 and t8 = 0 and t9 = 0 and t10 = 0 and t11 = 0 and t12 = 0 and t13 =0 and t14 = 0 and t15 = 0 and t16 = 0 and t17 = 0 and t18 = 0 and t19 = 0 and t20 = 0 and t21 = 0 and t22 = 0 and t23 = 0 and t24 = 0 and timestamp >= '{stringDate}' and device_id = {gateway_id};")
                        coun = myCursor.fetchall()
                        count = coun[0]
                        if count == 0:
                            myCursor.execute(f"select name from ALARM where id = 2;")
                            cal = myCursor.fetchall()
                            i = 0   
                            for row in cal:
                                tmp.append(row)
                                i = i+1
                            alarmName = tmp[0][0]
                            myCursor.execute(f"select SYSTEM_FEATURES_id from device JOIN SYSTEM_FEATURES on SYSTEM_FEATURES.id=device.SYSTEM_FEATURES_id where device.id = {gateway_id};")
                            cal = myCursor.fetchall()
                            i = 0
                            del tmp
                            tmp = []
                            for row in cal:
                                tmp.append(row)
                                i = i+1
                    except:
                        textToWrite = b"Error obtaining the system features id from device\n"
                        logFile = open("logs/backendErrors.txt", "ab")
                        cDate = datetime.now()           
                        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                
                        logFile.write(stringDate+bytes(" : ",'ascii')+textToWrite)
                        logFile.close()
                        print(textToWrite.decode('ASCII'))     
                        idCaracteristicas = tmp[0][0]
                        try:
                            myCursor.execute("select id from ALARM where id= {idCaracteristicas};")
                            aId = myCursor.fetchall()
                            if len(aId)!=0:
                                alarmId = aId

                                sql = "INSERT INTO `ALARM_HISTORY`(`name`, `date`,`ALARM_id`,`noFlow`) VALUES(%s, %s,%s, %s)"
                                values = alarmName, cDate,alarmId,1
                                myCursor.execute(sql, values)
                        except:
                            textToWrite = b"Error inserting the alarm history\n"
                            logFile = open("logs/backendErrors.txt", "ab")
                            cDate = datetime.now()           
                            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                    
                            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                            logFile.close()
                            print(textToWrite.decode('ASCII')) 
                    ##############################################  
                except:
                    textToWrite = b"Error in the stand\n"
                    logFile = open("logs/backendErrors.txt", "ab")
                    cDate = datetime.now()           
                    stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            
                    logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                    logFile.close()
                    print(textToWrite.decode('ASCII')) 
            elif typ == "atcom" or typ == "conf": 
                try:
                    response = mqttRecieved[1]
                    timestamp = datetime.now()

                    try:
                        myCursor.execute("SELECT MAX(id) FROM REMOTE_CONSOLE")
                        REMOTE_CONSOLE_id = myCursor.fetchone()
                        remoteId = REMOTE_CONSOLE_id[0]
                        
                        sql = "INSERT INTO `REMOTE_CONSOLE_RESPONSE`(`response`, `timestamp`, `REMOTE_CONSOLE_id`) VALUES(%s, %s, %s)"
                        values = response, timestamp, remoteId
                        myCursor.execute(sql, values)                
                    except:
                        textToWrite = b"Error inserting values on SYSTEM_FEATURES\n"
                        logFile = open("logs/backendErrors.txt", "ab")
                        cDate = datetime.now()           
                        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                
                        logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                        logFile.close()
                        print(textToWrite.decode('ASCII'))
                except:
                        textToWrite = b"Error inserting values on SYSTEM_FEATURES\n"
                        logFile = open("logs/backendErrors.txt", "ab")
                        cDate = datetime.now()           
                        stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                
                        logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                        logFile.close()
                        print(textToWrite.decode('ASCII'))  
            # try: # JSON send part
            #     mqttRecieved = messageReceivedDecoded.split(";") 
            #     serialNumber = msg.topic.replace("t", "")
            #     serialNumber = int(serialNumber)


            #     # comprobacion topicos para entrar por quitar cuando funcione
            #     if mqttRecieved[0] == "stand" and (serialNumber == 2 or serialNumber == 1 ):

            #         #  to check all the variables and their values
            #         # "connectionData": connectionData, #[signal, sinr, cellId] Number array
            #         cDate = datetime.fromtimestamp(int(mqttRecieved[4]))   
            #         tr = 2 # cycle shift                       
            #         # cDate = cDate.replace(day = cDate.day-tr)
            #         # cDate = cDate.replace(hour = cDate.hour-tr)
            #         cDatePrevious = cDate.replace(hour = cDate.hour-tr)
            #         # inserting 0 before the number in case number < 10

            #         if cDate.month < 10:
            #             month = "0"+str(cDate.month)
            #         else:
            #             month = str(cDate.month)
                
            #         if cDate.day < 10:
            #             day = "0"+str(cDate.day)
            #         else:
            #             day = str(cDate.day)

            #         if cDate.hour < 10:
            #             hour = "0"+str(cDate.hour)
            #         else:
            #             hour = str(cDate.hour) 

            #         if cDatePrevious.month < 10:
            #             monthPrevious = "0"+str(cDatePrevious.month)
            #         else:
            #             monthPrevious = str(cDatePrevious.month)
                
            #         if cDatePrevious.day < 10:
            #             dayPrevious = "0"+str(cDatePrevious.day)
            #         else:
            #             dayPrevious = str(cDatePrevious.day)

            #         if cDatePrevious.hour < 10:
            #             hourPrevious = "0"+str(cDatePrevious.hour)
            #         else:
            #             hourPrevious = str(cDatePrevious.hour) 

            #         stringDate = str(cDate.year) + "-" + month + "-" + day + " " + hour + ":%%:%%"
            #         stringDatePrevious = str(cDate.year) + "-" + monthPrevious + "-" + dayPrevious + " " + hourPrevious + ":%%:%%"
            #         try:
            #             del tmp
            #             tmp = []
            #             # print(f"SELECT t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23 FROM GATEWAY_HISTORY where timestamp like '{stringDate}' order by id desc limit 1;")
            #             myCursor.execute(f"SELECT t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16,t17,t18,t19,t20,t21,t22,t23 FROM GATEWAY_HISTORY where timestamp like '{stringDate}' order by id desc limit 1;")
            #             cal = myCursor.fetchone()
            #             i = 0   
            #             for row in cal:
            #                 tmp.append(row)
            #                 i = i+1
            #             # print(f"SELECT t24 FROM GATEWAY_HISTORY where timestamp like '{stringDatePrevious}' order by id desc limit 1;")
            #             myCursor.execute(f"SELECT t24 FROM GATEWAY_HISTORY where timestamp like '{stringDatePrevious}' order by id desc limit 1;")
            #             REMOTE_CONSOLE_id = myCursor.fetchone()
            #             # print(REMOTE_CONSOLE_id)
            #             t24 = REMOTE_CONSOLE_id[0]
            #             tmp[0] = str(int(tmp[0])+int(t24))
            #             # print(tmp)
            #         except:
            #             textToWrite = b"Error obtaining the 24 elements \n"
            #             logFile = open("logs/backendErrors.txt", "ab")
            #             cDate = datetime.now()           
            #             stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            #             logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                
            #             logFile.close()
            #             print(textToWrite.decode('ASCII'))
                    
            #         # try:
                        
            #         #     acumulatedTmp = []
            #         #     countAcumulated = []
            #         #     myCursor.execute(f"SELECT count(accumulated) FROM GATEWAY_HISTORY where device_id = {serialNumber} order by accumulated desc limit 1;")
            #         #     cal = myCursor.fetchone()
            #         #     for row in cal:
            #         #         countAcumulated.append(row)
            #         #     if countAcumulated[0] != 0:
            #         #         # print(f"SELECT accumulated FROM GATEWAY_HISTORY where device_id = {serialNumber} order by accumulated desc limit 1;")
            #         #         myCursor.execute(f"SELECT accumulated FROM GATEWAY_HISTORY where device_id = {serialNumber} order by accumulated desc limit 1;")
            #         #         cal = myCursor.fetchone()
            #         #         for row in cal:
            #         #             acumulatedTmp.append(row)
            #         #     else:
            #         #         acumulatedTmp.append(0)
                            
            #         # except:
            #         #     textToWrite = b"Error obtaining the accumulated \n"
            #         #     logFile = open("logs/backendErrors.txt", "ab")
            #         #     cDate = datetime.now()           
            #         #     stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
                
            #         #     logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            #         #     logFile.close()
            #         #     print(textToWrite.decode('ASCII'))
            #         # accumulated
            #         # if len(acumulatedTmp) != 0:
            #         #     accumulated = acumulatedTmp
            #         # else:
            #         #     accumulated = 0


            #         if 0 != G5_RSRP:
            #             signal = G5_RSRP 
            #         elif 0 != G4_RSRP:
            #             signal = G4_RSRP 
            #         else:
            #             signal = G3_RSCP

            #         if 0 != G5_RSSI:
            #             rssi = G5_RSSI 
            #         elif 0 != G4_RSSI:
            #             rssi = G4_RSSI 
            #         else:
            #             rssi = G3_ecio

            #         if alarmName == "":
            #             alarmName = "empty"

            #         if 0 != G5_SINR:
            #             sinr = G5_SINR 
            #         elif 0 != G4_SINR:
            #             sinr = G4_SINR 
            #         else:
            #             sinr = 0

            #         if alarmName == "":
            #             alarmName = "empty"    
            #         rssi

            #         alarmArray = []

            #         if fuga:
            #             alarmArray.append("true")
            #         else:
            #             alarmArray.append("false")
                        
            #         if alarmName == "sinCaudal":
            #             alarmArray.append("true") 
            #         else:
            #             alarmArray.append("false")

            #         if subdimension:
            #             alarmArray.append("true")
            #         else:
            #             alarmArray.append("false")
            #        # 
            #         try:
            #             vol = []
            #             # print(f"select volumeLiters from SYSTEM_FEATURES WHERE ID = (SELECT SYSTEM_FEATURES_id from device where id = {serialNumber});")
            #             myCursor.execute(f"select diameterFlow from SYSTEM_FEATURES WHERE ID = (SELECT SYSTEM_FEATURES_id from device where id = {serialNumber});")
            #             cal = myCursor.fetchone()
            #             for row in cal:
            #                 vol.append(row)
            #             # print(vol)
            #         except:
            #             textToWrite = b"Error obtaining the volume liters\n"
            #             logFile = open("logs/backendErrors.txt", "ab")
            #             cDate = datetime.now()           
            #             stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            #             logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
                
            #             logFile.close()
            #             print(textToWrite.decode('ASCII'))

            #         volumeLiters = vol[0]
            #         print(volumeLiters)
            #         connectionData = [int(signal),int(sinr),int(rssi),int(CELL_ID)]   
            #         connectionData = list(map(lambda x: int(x),connectionData))
            #         # temporal para no mandarle lo que da la placa
            #         # waterMeterReadingTmp = list(map(lambda x: int(x),tmp))

            #         waterMeterReadingTmp=[0 for o in range(24)]

            #         waterMeterReadingTmp[0] = waterMeterReadingTmp[0]+int(accumulated)
            #         waterMeterReading = np.cumsum(waterMeterReadingTmp)*volumeLiters/1000
            #         id_num = "F"+(9-len(str(serialNumber)))*"0"+str(serialNumber)
            #         envioJson(id_num,Ctimestampv,waterMeterReading.tolist(),connectionData,battery,alarmArray) 
            #     # print(str(serialNumber)+";"+str(Ctimestampv)+";"+str(vectorTimestamps)+";"+str(signal)+","+str(sinr)+","+str(CELL_ID)+";"+str(battery)+";"+str(alarmName))
            # except:
            #         logFile = open("logs/backendErrors.txt", "ab")
            #         cDate = datetime.now()           
            #         textToWrite = b"Error calling the json function\n"
            #         stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            #         logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            #         logFile.close()
            #         print(textToWrite.decode('ASCII'))  
        elif msg.topic in vectorTopicRx:
            print("lectura placa")
            print(msg.payload)
            print(msg.topic)            
        else:
            print("warning!")
            print(msg.payload)
            print(msg.topic)
    client.subscribe(topic)
    client.on_message = on_message


def run():
    # directory for the logs
    directory = "logs"
    makingLogsDir(directory)
    while True:
        try:
            client = connect_mqtt() # conection to the server
            vectorTopic = load()
            vectorTopicTx = vectorTopic[0]
            vectorTopicRx = vectorTopic[1]
            subscribe(client,vectorTopicTx,vectorTopicRx) #connects to broker, deberiamos cambiar el nombre de la fnc
            client.loop_forever() #loop
        except KeyboardInterrupt:
            res = input("Ctrl-c was pressed. Do you really want to exit? y/n ")
            if res == 'y':
                exit(0)
        except:
            logFile = open("logs/backendErrors.txt", "ab")
            cDate = datetime.now()           
            stringDate = str(cDate.year) + "-" + str(cDate.month) + "-" + str(cDate.day) + " " + str(cDate.hour) + ":" + str(cDate.minute) + ":" + str(cDate.second)
            textToWrite = b"Principal thread error\n"
            logFile.write(bytes(stringDate,'ascii')+bytes(" : ",'ascii')+textToWrite)
            logFile.close()
            print(textToWrite.decode('ASCII'))

if __name__ == '__main__':
    run()
