

messageType = "test1"
device = "test1"
deviceType = "test1"
sequencyNumber = "test1"
time = "test1"
data = "test1"
operator = "test1"
fixedLat = 0
fixedLng = 0
lat = 0
lng = 0
radius = 0
source = "test1"
status = "test1"

countryCode = 000
linkQuality = 10

message = {
    "messageType": messageType,
    "device":device,
    "deviceType":deviceType,
    "sequencyNumber":sequencyNumber,
    "time":time,
    "data":data,
    "operator":operator,
    "fixedLat":fixedLat,
    "fixedLng":fixedLng,
    "lat":lat,
    "lng":lng,
    "radius":radius,
    "source":source,
    "status":status,
    "countryCode":countryCode,
    "linkQuality":linkQuality
    }

print(message)