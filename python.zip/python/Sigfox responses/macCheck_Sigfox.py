import mysql.connector

def ifExists(macSite):
    value = True
    if macSite == 0:
        value = False
    return value

def stringToMac(myString):
    if len(myString) == 12:
        mac = ''
        for i in range(2, 12, 2): # bucle for since 2 to 12-2
            mac += myString[i-2:i]+':'
        mac += myString[10:12]
    else:
        print("error")
    return mac

def macCheck(macs,lat,lng):
   # macs = str(macs)
    lock = True
    latitude = lat
    longitude = lng
    print(macs)
    lengthMac = 12
    mac1 = macs[0:12]
    if len(macs) == 24:
        mac2 = macs[12:len(macs)]
    else:
        mac2 = mac1
    positions = [lat,lng]
    # DDBB credentials
    mydbConnector = mysql.connector.connect(
                    host="localhost", 
                    user="adminIOT",
                    password="2zKxspRuwdTgiABEo9",
                    database="iotPlatform",
                    )

    # cursor created
    myCursor = mydbConnector.cursor()
    #alegre
    try:
        sql = "select count(macValue) from macAlegre where macValue = %s or macValue = %s;"
        #print(f"SELECT count(macValue) FROM macAlegre  where macValue = '{mac1}' or macValue = '{mac2}';")

        val = (mac1,mac2)
        myCursor.execute(sql, val)

        macAlegre_exists = 0
        for row in myCursor.fetchall():
            macAlegre_exists = row[0]

    except:
        print("error obtaining alegre macs")
    # ford
    if macAlegre_exists == 0:
        try:
            sql = "SELECT count(macValue) FROM macFord  where macValue = %s or macValue = %s;"
            #print(f"SELECT count(macValue) FROM macFord  where macValue = '{mac1}' or macValue = '{mac2}';")
            val = (mac1,mac2)
            myCursor.execute(sql, val)

            macFord_exists = 0
            for row in myCursor.fetchall():
                macFord_exists = row[0]

        except:
            print("error obtaining ford macs")
    # yanfeng
    if macAlegre_exists == 0 and macFord_exists == 0:
        try:
            sql = "SELECT count(macValue) FROM macYanfeng  where macValue = %s or macValue = %s;"
            print(f"SELECT count(macValue) FROM macYanfeng  where macValue = '{mac1}' or macValue = '{mac2}';")
            val = (mac1,mac2)
            myCursor.execute(sql, val)

            macYangfeng_exists = 0
            for row in myCursor.fetchall():
                macYangfeng_exists = row[0]
        except:
            print("error obtaining yanfeng macs")
    #carpa
    if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0:
        try:
            sql = "SELECT count(macValue) FROM macCarpa  where macValue = %s or macValue = %s;"
            #print(f"SELECT count(macValue) FROM macYangfeng  where macValue = '{mac1}' or macValue = '{mac2}';")
            val = (mac1,mac2)
            myCursor.execute(sql, val)

            macCarpa_exists = 0
            for row in myCursor.fetchall():
                macCarpa_exists = row[0]
        except:
            print("error obtaining carpa macs")   
    #66
    if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and macCarpa_exists == 0:
        try:
            sql = "SELECT count(macValue) FROM mac66  where macValue = %s or macValue = %s;"
            #print(f"SELECT count(macValue) FROM macYangfeng  where macValue = '{mac1}' or macValue = '{mac2}';")
            val = (mac1,mac2)
            myCursor.execute(sql, val)

            mac66_exists = 0
            for row in myCursor.fetchall():
                mac66_exists = row[0]
        except:
            print("error obtaining 66 macs")   
    #epc
    if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and macCarpa_exists == 0 and mac66_exists == 0:
        try:
            sql = "SELECT count(macValue) FROM macEpc  where macValue = %s or macValue = %s;"
            #print(f"SELECT count(macValue) FROM macYangfeng  where macValue = '{mac1}' or macValue = '{mac2}';")
            val = (mac1,mac2)
            myCursor.execute(sql, val)

            macEpc_exists = 0
            for row in myCursor.fetchall():
                macEpc_exists = row[0]
        except:
            print("error obtaining EPC macs")    
    #MLV
    if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and macCarpa_exists == 0 and mac66_exists == 0 and macEpc_exists == 0:
        try:
            sql = "SELECT count(macValue) FROM macMlv  where macValue = %s or macValue = %s;"
            #print(f"SELECT count(macValue) FROM macYangfeng  where macValue = '{mac1}' or macValue = '{mac2}';")
            val = (mac1,mac2)
            myCursor.execute(sql, val)

            macMlv_exists = 0
            for row in myCursor.fetchall():
                macMlv_exists = row[0]
        except:
            print("error obtaining MLV macs")                                        
    # print("alegre")               
    # print(macAlegre_exists)
    # # printing values
    # if macAlegre_exists == 0:
    #     print("ford")
    #     print(macFord_exists)
    # if macAlegre_exists == 0 and macFord_exists == 0 :
    #     print("yangfeng")
    #     print(macYangfeng_exists)
    # # end of the printing values

    if ifExists(macAlegre_exists) == True:
        # is in alegre
        latitude = 39.3892
        longitude = -0.3952
    else:
        if macAlegre_exists == 0 and ifExists(macFord_exists) == True:
            # is in ford
            latitude = 39.3190
            longitude = -0.4156
        else:
            if macAlegre_exists== 0 and macFord_exists == 0 and ifExists(macYangfeng_exists) == True :
                #is in yanfeng
                #latitude = 39.3221
                #longitude = -0.42420
                latitude = 39.32203400807103 
                longitude = -0.4247571385429517
            else:
                if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and ifExists(macCarpa_exists) == True :
                    #is in carpa
                    #latitude = 39.311927
                    #longitude = -0.415686
                    latitude = 39.311927
                    longitude = -0.415686
                else:
                    if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and macCarpa_exists == 0 and ifExists(mac66_exists) == True :
                        #is in 66
                        #latitude = 39.315111
                        #longitude =-0.415062
                        latitude = 39.315111
                        longitude = -0.415062           
                    else:
                        if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and macCarpa_exists == 0 and mac66_exists == 0 and ifExists(macEpc_exists) == True :
                            #is in epc
                            #latitude = 39.312615
                            #longitude = -0.414711
                            latitude = 39.312615 
                            longitude = -0.414711
                        else:
                            if macAlegre_exists == 0 and macFord_exists == 0 and macYangfeng_exists == 0 and macCarpa_exists == 0 and mac66_exists == 0 and macEpc_exists == 0 and ifExists(macMlv_exists) == True :
                                #is in mlv
                                #latitude = 39.324926, 
                                #longitude = -0.410842
                                latitude = 39.324926
                                longitude = -0.410842 
                            else:
                                print("entro en ese else")
                                # is in the uknown
                                # if source == 6 and status == 1:
                                #     geolocate(mac1,mac2)
                                # else:
                                lock = False
    
    positions = [latitude,longitude,lock]

    #
    return positions