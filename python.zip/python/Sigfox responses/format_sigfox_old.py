import time


def switch_message(argument):
    messageType = "Unknown"
    if argument == "00":
        messageType = "Keep alive 1"
    elif argument == "01":
        messageType = "Keep alive 2"
    elif argument == "11":
        messageType = "Armado manual"
    elif argument == "14":
        messageType = "Desarmado"
    elif argument == "17":
        messageType = "Autoarmado"
    elif argument == "20":
        messageType = "Inicio Viaje"
    elif argument == "21":
        messageType = "Fin Viaje"
    elif argument == "22":
        messageType = "En movimiento"
    elif argument == "42":
        messageType = "Doblado"
    elif argument == "43":
        messageType = "Desplegado"
    elif argument == "62":
        messageType = "Desplegado ON"
    elif argument == "63":
        messageType = "Desplegado OFF"
    elif argument == "81":
        messageType = "Downlink por botón"

    return messageType


def switch_battery(argument):
    battery = "Unknown"
    if argument == "30":
        battery = "3,0V - OK"
    elif argument == "29":
        battery = "2,9V - OK"
    elif argument == "28":
        battery = "2,8V - OK"
    elif argument == "27":
        battery = "2,7V - OK"
    elif argument == "26":
        battery = "2,6V - OK"
    elif argument == "25":
        battery = "2,5V - OK"
    elif argument == "24":
        battery = "2,4V - OK"
    elif argument == "23":
        battery = "2,3V - OK"
    elif argument == "22":
        battery = "2,2V - Batería Baja"
    elif argument == "21":
        battery = "2,1V - Batería Baja"
    elif argument == "20":
        battery = "2,0V - Batería Baja"
    elif argument == "19":
        battery = "1,9V - Alerta Batería Critica"
    elif argument == "18":
        battery = "1,8V - Alerta Batería Critica"

    return battery


def formatSigfoxData(device, dataImported):

    sizeData = len(dataImported)
    error = False

    if dataImported[0:2] == '37':
        mode = 'REED'  # Modo de funcionamiento
        mType = dataImported[2:4]  # Variable temporal para obtener el tipo de mensaje
        message_type = switch_message(mType)  # Tipo de mensaje en modo string
        temp_hum = dataImported[4:6]  # Variable con el sensor de temperatura y humedad, puede ser C0 o C8
        bat = dataImported[6:8]  # Variable temporal para el calculo de la bateria
        battery = switch_battery(bat)  # Variable tipo String con el voltaje de la bateria y el estado (ok, bateria baja o alerta critica)
        temp = dataImported[8:10]  # Variable temporal para el calculo de la temperatura
        if temp != '':
            temperature = (int(temp, 16) / 2) - 40  # Temperatura calculada (de -40º a 87,5º)
        else:
            f = open("message_error.txt", "a")
            f.write("dispositivo: " + device + ", mensaje: " + dataImported + "\n")
            f.close()
            error = True
            temperature = 0

        if temp_hum == 'c8':
            infs = dataImported[10:12]  # Variable temporal para el "info sensor"
            info_sensor = bin(int(infs, 16))[2:].zfill(8)  # Info sensor parseado
            if info_sensor[0] == '0':
                info_sensor = "OFF Doblado"
            elif info_sensor[0] == '1':
                info_sensor = "ON Desplegado"
        else:
            info_sensor = 'Null'  # Como este modo no tiene info_sensor, lo seteamos a NULL

    elif dataImported[0:2] == '2f': #es case sensitive, entonces se necesita poner en minuscula
        mode = 'TRACE ME TILT'  # Modo de funcionamiento
        mType = dataImported[2:4]  # Variable temporal para obtener el tipo de mensaje
        message_type = switch_message(mType)  # Tipo de mensaje en modo string
        temp_hum = dataImported[
                4:6]  # Variable con el sensor de temperatura y humedad, C0 por defecto en este caso
        bat = dataImported[6:8]  # Variable temporal para el calculo de la bateria
        battery = switch_battery(
            bat)  # String con el voltaje de la bateria y el estado (ok, bateria baja o alerta critica)
        temp = dataImported[8:10]  # Variable temporal para el calculo de la temperatura
        if temp != '':
            temperature = (int(temp, 16) / 2) - 40  # Temperatura calculada (de -40º a 87,5º)
        else:
            f = open("message_error.txt", "a")
            f.write("dispositivo: " + device + ", mensaje: " + dataImported + "\n")
            f.close()
            error = True
            temperature = 0

        info_sensor = 'Null'  # Como este modo no tiene info_sensor, lo seteamos a NULL

    else:
        print("error, unknown mode")

        mode = 'Null'  # Modo de funcionamiento
        message_type = 'Null'  # Tipo de mensaje en modo string
        temp_hum = 'Null'  # Variable con el sensor de temperatura y humedad, puede ser C0 o C8
        battery = 'Null'  # Variable tipo String con el voltaje de la bateria y el estado (ok, bateria baja o alerta critica)
        temperature = 0  # Temperatura calculada (de -40º a 87,5º)
        info_sensor = 'Null'  # Como este modo no tiene info_sensor, lo seteamos a NULL

        f = open("message_error.txt", "a")
        f.write("dispositivo: " + device + ", mensaje: " + dataImported + "\n")
        f.close()

        error = True

    return error, mode, message_type, temp_hum, battery, temperature, info_sensor