from getOneDeviceFromSigfox  import getDeviceFromSigfox
print(getDeviceFromSigfox("26F5492"))