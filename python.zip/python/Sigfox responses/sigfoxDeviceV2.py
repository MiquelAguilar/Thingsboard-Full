import paho.mqtt.client as mqtt


def sendDataToThingsboard(msg, token):
    THINGSBOARD_HOST = '192.168.10.69'
    ACCESS_TOKEN = token

    client = mqtt.Client()

    # Set access token
    client.username_pw_set(ACCESS_TOKEN)

    # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
    client.connect(THINGSBOARD_HOST, 1883, 60)

    client.loop_start()

    try:
        print(msg)
        client.publish('v1/devices/Sigfox/telemetry', msg, 1)
        print("sended")
    except KeyboardInterrupt:
        pass

    client.loop_stop()
    client.disconnect()
