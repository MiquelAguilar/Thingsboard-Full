import json, requests, time, mysql.connector

from provisioningSigfoxV2 import provisionSigfoxDevice
from sigfoxDeviceV2 import sendDataToThingsboard
from format_sigfox  import formatSigfoxData
from macCheck_Sigfox import macCheck

mydbConnector = mysql.connector.connect(
    host="localhost",
    user="adminIOT",
    password="2zKxspRuwdTgiABEo9",
    database="iotPlatform",
)
myCursor = mydbConnector.cursor()

user = '61979e788533432439f9e49c'
password = '8c9871c2280ac561f118cb36ffc313c9'
url = "https://api.sigfox.com/v2/devices/"
response1 = requests.get(url, auth=(user, password))


def getDeviceFromSigfox(d_id):
    # Se inicializan variables para los bucles
    device = d_id
    i = 0
    response2 = []

    ####### se solicita toda la información de ese dispositivo desde que fué creado #####
    url1 = url+str(device)+"/messages"
    print("ay")
    print(url1)
    response2.append(requests.get(url1, auth=(user, password)))
    print(response2[i].json())
    paging = response2[i].json()['paging']
    #continue_loop = True

    while True:
        time.sleep(1)
        if len(paging) != 0:
            i = i + 1
            print(paging)
            urlNext = paging['next']
            response2.append(requests.get(urlNext, auth=(user, password)))
            print(response2[i].status_code)
            if response2[i].status_code == 200:
                paging = response2[i].json()['paging']
            else:
                break
        else:
            break

    # Variables para el siguiente while.
    j=0

    sql = "SELECT token FROM sigfoxCredentials WHERE `name`= %s;"
    val = device
    myCursor.execute(sql, (val,))

    device_exists = 0
    for row in myCursor.fetchall():
        device_exists = row[0]

    while j <= i:
        valuesInverted = sorted(response2[i-j].json()['data'], key=lambda k: k['seqNumber'], reverse=False)
        if device_exists:
            ####### se separa la información en variables #####
            for values in valuesInverted:
                timestamp = values['time']
                timestamp2 = timestamp/1000
                data = values['data']
                date = time.strftime("%d-%m-%Y %H:%M:%S", time.gmtime(timestamp2))
                seqNumber = values['seqNumber']
                operator = values['operator']
                country = values['country']
                if len(values['computedLocation']) > 0:
                    computedLocation = values['computedLocation'][0]
                lat = computedLocation['lat']
                lng = computedLocation['lng']
                radius = computedLocation['radius']
                source = computedLocation['source']

                print(f"estos es lo que me entra {data}")
                print(f"estos es la longitud{len(data)}")
                
                if len(data) <= 24:
                    noEntres = True
                    error, mode, message_type, temp_hum, battery, temperature, info_sensor = formatSigfoxData(device, data)
                    if mode == 'macImport':
                        mac = data[6:]
                        lat = macCheck(mac,lat,lng)[0]
                        lng = macCheck(mac,lat,lng)[1]
                        lock =  macCheck(mac,lat,lng)[2]
                        print(f"esto es una mac dicen:{mac}")
                        print(lock)
                        if lock:
                            source = 6
                        else:
                            source = 2

                        # if source == 6 and error == False:
                        #     print("entraria en el mensaje")

                    if error == False and noEntres == True:
                        if source == 6:
                            msg = "{"+f'"ts":{timestamp}, "values":{{"device":"{device}","timestamp":{timestamp},"mode":"{mode}", "message_type":"{message_type}", "temp_hum":"{temp_hum}", "battery":"{battery}", "temperature":{temperature}, "info_sensor":"{info_sensor}", "sequenceNumber":{seqNumber},"date":"{date}","data":"{data}","operator":"{operator}","latitude":{lat},"longitude":{lng},"radius":{radius},"country":"{country}"}}'+"}"
                            # print(msg)
                            sendDataToThingsboard(msg, device_exists)
                            # time.sleep(3)
                        # f = open("import.csv", "a")
                        # f.write(msg)
                        # f.write(device_exists)
                        # f.write(";")

                        # f.close()
                        # print("post send")

                        #sql = "INSERT INTO `sigfoxDevice`(`device`, `sequenceNumber`, `time`, `data`, `operator`, `lat`, `lng`, `radius`) VALUES(%s, %s, %s, %s, %s, %s, %s, %s); "
                       # val = device, seqNumber, timestamp, data, operator, lat, lng, radius
                        #myCursor.execute(sql, val)
                        #mydbConnector.commit()
                        #time.sleep(2)

            j = j + 1
        else:
            print("doesntExists")
            token = provisionSigfoxDevice(device)
            device_exists = token
            print("provisioned")









